# -*- coding: utf-8 -*-
"""
PDS-X Auto-Importer: Ak�ll�, Otomatik ve Kendi Kendini Onaran Paket Y�neticisi
Versiyon: 1.7.9.8
Tarih: 22 Haziran 2025
Yazar: xAI (Gemini ile olu�turuldu, fikir Mete Dinler, d�zenleyen GitHub Copilot-Geminni)
"""

import sys
import io

# Windows'ta konsol karakter kodlamas� sorunlar�n� ��zmek i�in stdout ve stderr'i yeniden yap�land�r.
if sys.platform == "win32":
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
        # Bu sat�r, print() fonksiyonunun do�rudan UTF-8 kullanmas�n� sa�lar.
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except (TypeError, ValueError) as e:
        # Bu hata, betik bir IDE i�inde veya zaten uyumlu bir terminalde �al��t�r�ld���nda olu�abilir.
        # Bu durumda, genellikle ek bir yap�land�rmaya gerek yoktur.
        print(f"[PDS-X UYARI] Standart ak��lar yeniden yap�land�r�lamad�: {e}", file=sys.__stderr__)

from pathlib import Path
from typing import List, Dict, Optional, Any, Tuple
from enum import Enum
import json
import re
import ast
import time
import threading
import subprocess
import importlib
import queue
import argparse
import io
import shutil
import asyncio
import random
import logging
from datetime import datetime
from collections import deque
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
from statistics import stdev
from scipy.stats import f_oneway

# --- PDS-X �zel Hata S�n�flar� ---
# exception_manager3.py dosyas�ndan al�nm�� gibi davran�yoruz.
class PdsXException(Exception):
    """PDS-X i�in temel hata s�n�f�."""
    def __init__(self, message: str, code: str, context: Optional[Dict[str, Any]] = None):
        super().__init__(f"[PDS-X Error Code: {code}] {message}")
        self.message = message
        self.code = code
        self.context = context or {}

class PdsXImportError(PdsXException, ImportError):
    """Mod�l import edilirken olu�an hatalar i�in."""
    pass

class PdsXNotFoundError(PdsXException, FileNotFoundError):
    """Dosya veya kaynak bulunamad���nda."""
    pass

class PdsXConflictError(PdsXException):
    """Ba��ml�l�k �ak��malar� i�in �zel hata s�n�f�."""
    pass

class PdsXInstallationError(PdsXException):
    """Paket kurulumu s�ras�nda genel hata."""
    pass

# --- Lazy Loading Mekanizmas� ---
# Bu mekanizma, mod�lleri sadece ihtiya� duyuldu�unda y�kleyerek ba�lang�� s�resini k�salt�r.
psutil = None
numpy = None
packaging = None
sklearn_components = {}
keyboard = None
winreg = None
elasticsearch_client = None # De�i�tirildi
colorama = {}
graphviz_digraph = None # De�i�tirildi

def get_psutil():
    """psutil'i lazy loading ile y�kle"""
    global psutil
    if psutil is None:
        try:
            import psutil as ps
            psutil = ps
        except ImportError:
            print("[PDS-X] UYARI: 'psutil' y�klenemedi. Kaynak izleme devre d���.")
    return psutil

def get_numpy():
    """NumPy'� lazy loading ile y�kle"""
    global numpy
    if numpy is None:
        try:
            import numpy as np
            numpy = np
        except ImportError:
            print("[PDS-X] UYARI: 'numpy' y�klenemedi. Bilimsel hesaplama �zellikleri devre d���.")
    return numpy

def get_sklearn_components():
    """Sklearn bile�enlerini lazy loading ile y�kle"""
    global sklearn_components
    if not sklearn_components:
        try:
            from sklearn.ensemble import IsolationForest
            from sklearn.preprocessing import StandardScaler
            from sklearn.neural_network import MLPClassifier
            from sklearn.tree import DecisionTreeClassifier
            sklearn_components = {
                "IsolationForest": IsolationForest,
                "StandardScaler": StandardScaler,
                "MLPClassifier": MLPClassifier,
                "DecisionTreeClassifier": DecisionTreeClassifier,
            }
        except ImportError:
            print("[PDS-X] UYARI: 'scikit-learn' y�klenemedi. Anomali tespiti devre d���.")
    return sklearn_components

def get_packaging_libs():
    """'packaging' k�t�phanesi bile�enleri i�in lazy loader."""
    global packaging
    if packaging is None:
        try:
            from packaging.specifiers import SpecifierSet
            from packaging.version import Version
            from packaging.requirements import Requirement
            packaging = {
                "SpecifierSet": SpecifierSet,
                "Version": Version,
                "Requirement": Requirement,
            }
        except ImportError:
            print("[PDS-X] UYARI: 'packaging' k�t�phanesi bulunamad�. Geli�mi� s�r�m kontrol� devre d���.")
            packaging = {} # Bo� dictionary ata, b�ylece tekrar denemez
    return packaging

def get_elasticsearch_client():
    """Elasticsearch istemcisini lazy loading ile y�kle."""
    global elasticsearch_client
    if elasticsearch_client is None:
        try:
            from elasticsearch import Elasticsearch
            elasticsearch_client = Elasticsearch
        except ImportError:
            print("[PDS-X] UYARI: 'elasticsearch' k�t�phanesi bulunamad�. Elasticsearch entegrasyonu devre d���.")
            elasticsearch_client = False # Tekrar denenmemesi i�in False olarak i�aretle
    return elasticsearch_client

def get_graphviz_digraph():
    """Graphviz Digraph'� lazy loading ile y�kle."""
    global graphviz_digraph
    if graphviz_digraph is None:
        try:
            from graphviz import Digraph
            graphviz_digraph = Digraph
        except ImportError:
            print("[PDS-X] UYARI: 'graphviz' k�t�phanesi bulunamad�. Ba��ml�l�k grafi�i olu�turma devre d���.")
            graphviz_digraph = False # Tekrar denenmemesi i�in False olarak i�aretle
    return graphviz_digraph

# Di�er lazy loader'lar
try:
    import winreg
except ImportError:
    winreg = None

try:
    from colorama import Fore, Style
    colorama = {'Fore': Fore, 'Style': Style}
except ImportError:
    # colorama yoksa, renk kodlar� olmadan �al��acak sahte nesneler olu�tur
    class DummyColor:
        def __getattr__(self, name):
            return ''
    colorama = {'Fore': DummyColor(), 'Style': DummyColor()}


# --- Temel Yap�land�rma ve Sabitler ---
BASE_DIR = Path(__file__).parent
LOG_DIR = BASE_DIR / "logs"
VENV_DIR = BASE_DIR / ".pdsx_isolated_env"
CACHE_DIR = BASE_DIR / ".pdsx_cache"
ALIAS_FILE = BASE_DIR / "pdsx_aliases.txt"
TERMINAL_LOG_FILE = LOG_DIR / "pdsX_terminal.log"
JSONL_LOG_FILE = LOG_DIR / "pdsx_terminal.jsonl"

# --- �al��ma Modlar� ---
class OperatingMode(Enum):
    NORMAL = "NORMAL"
    SUPPRESSED = "SUPPRESSED"
    SILENT = "SILENT"
    TOTAL_SILENT = "TOTAL_SILENT"

class ModeManager:
    """�al��ma modunu y�netir ve ��kt�lar� buna g�re kontrol eder."""
    def __init__(self, mode: OperatingMode):
        self.mode = mode
        self.is_suppressed = mode in [OperatingMode.SUPPRESSED, OperatingMode.SILENT, OperatingMode.TOTAL_SILENT]
        self.is_silent = mode in [OperatingMode.SILENT, OperatingMode.TOTAL_SILENT]

    def should_print_terminal(self) -> bool:
        return not self.is_silent

    def should_log_standard(self) -> bool:
        return self.mode != OperatingMode.TOTAL_SILENT

    def print(self, message: str, pdsx_prefix: bool = False):
        if self.mode == OperatingMode.NORMAL:
            print(message)
        elif self.mode == OperatingMode.SUPPRESSED and pdsx_prefix:
            print(message)

mode_manager: Optional[ModeManager] = None

# --- Geli�mi� Loglama Sistemi ---
class AdvancedLogger:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(AdvancedLogger, cls).__new__(cls)
        return cls._instance

    def __init__(self, log_dir: Path = LOG_DIR, terminal_log_path: Path = TERMINAL_LOG_FILE, jsonl_log_path: Path = JSONL_LOG_FILE):
        if hasattr(self, 'initialized'):
            return
        
        self.log_dir = log_dir
        self.log_dir.mkdir(exist_ok=True)

        # Log Yedekleme
        if terminal_log_path.exists():
            try:
                backup_path = terminal_log_path.with_suffix('.log.bak')
                if backup_path.exists():
                    backup_path.unlink()
                terminal_log_path.rename(backup_path)
            except OSError as e:
                print(f"[PDS-X] Uyar�: Terminal log yede�i al�namad�: {e}")

        self.logger = logging.getLogger("PDS_X_Logger")
        self.logger.setLevel(logging.DEBUG)
        self.logger.propagate = False

        # JSONL Handler
        self.jsonl_handler = logging.FileHandler(jsonl_log_path, mode='a', encoding='utf-8')
        self.jsonl_handler.setFormatter(logging.Formatter('{"time": "%(asctime)s", "level": "%(levelname)s", "message": "%(message)s"}'))
        self.logger.addHandler(self.jsonl_handler)

        # Standart File Handler
        self.log_file_path = self.log_dir / "pdsx_auto_importer.log"
        self.file_handler = logging.FileHandler(self.log_file_path, mode='a', encoding='utf-8')
        self.file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(self.file_handler)

        # Console Handler
        self.console_handler = logging.StreamHandler(sys.stdout)
        self.console_handler.setFormatter(logging.Formatter('%(message)s'))
        self.logger.addHandler(self.console_handler)

        self.initialized = True

    def log(self, level: str, message: str, *args, **kwargs):
        log_func = getattr(self.logger, level.lower(), self.logger.info)
        
        # Mesajdaki JSON uyumsuz karakterleri temizle
        cleaned_message = json.dumps(message)[1:-1]
        
        # ModeManager'a g�re handler'lar� y�net
        if mode_manager:
            if not mode_manager.should_print_terminal() and self.console_handler in self.logger.handlers:
                self.logger.removeHandler(self.console_handler)
            elif mode_manager.should_print_terminal() and self.console_handler not in self.logger.handlers:
                self.logger.addHandler(self.console_handler)

            if not mode_manager.should_log_standard() and self.file_handler in self.logger.handlers:
                self.logger.removeHandler(self.file_handler)
            elif mode_manager.should_log_standard() and self.file_handler not in self.logger.handlers:
                self.logger.addHandler(self.file_handler)
        
        log_func(cleaned_message, *args, **kwargs)

class Tee(io.TextIOWrapper):
    """Hem dosyaya hem de orijinal stdout/stderr'e yazan bir nesne."""
    def __init__(self, original_stream, log_file_path):
        self.original_stream = original_stream
        try:
            self.log_file = open(log_file_path, 'a', encoding='utf-8', buffering=1)
        except IOError as e:
            self.log_file = None
            self.original_stream.write(f"[PDS-X] HATA: Terminal log dosyas� a��lamad�: {log_file_path}\n{e}\n")
        
        # sys.stdout/stderr'i de�i�tir
        if original_stream == sys.stdout:
            sys.stdout = self
        else:
            sys.stderr = self

    def write(self, text):
        self.original_stream.write(text)
        if self.log_file:
            self.log_file.write(text)

    def flush(self):
        self.original_stream.flush()
        if self.log_file:
            self.log_file.flush()

    def close(self):
        if self.original_stream == sys.stdout:
            sys.stdout = self.original_stream
        else:
            sys.stderr = self.original_stream
        if self.log_file:
            self.log_file.close()

# --- EKS�K YARDIMCI SINIFLARIN TANIMLANMASI ---

class DependencyRegistry:
    """Kurulu paketlerin ve ba��ml�l�klar�n�n kayd�n� tutar."""
    def __init__(self, logger: AdvancedLogger, file_path: Path = BASE_DIR / "dependencies.json"):
        self.logger = logger
        self.file_path = file_path
        self.registry = self._load()

    def _normalize_name(self, package_name: str) -> str:
        """Paket ad�n� PEP 503 normallerine g�re standartla�t�r�r (k���k harf, _ -> -)."""
        if not package_name:
            return ""
        return package_name.lower().replace("_", "-")

    def _load(self) -> Dict[str, Any]:
        """Kay�t dosyas�n� y�kler."""
        if not self.file_path.exists():
            self.logger.log("info", "Ba��ml�l�k kay�t dosyas� bulunamad�, yeni bir tane olu�turuluyor.")
            return {"version": "1.0", "packages": {}}
        try:
            with open(self.file_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, IOError) as e:
            self.logger.log("error", f"Ba��ml�l�k kay�t dosyas� y�klenirken hata: {e}. Yeni bir kay�t olu�turuluyor.")
            return {"version": "1.0", "packages": {}}

    def save(self):
        """Mevcut kay�t durumunu dosyaya yazar."""
        try:
            with open(self.file_path, "w", encoding="utf-8") as f:
                json.dump(self.registry, f, indent=4)
            self.logger.log("debug", f"Ba��ml�l�k kayd� �uraya kaydedildi: {self.file_path}")
        except IOError as e:
            self.logger.log("error", f"Ba��ml�l�k kay�t dosyas� kaydedilirken hata: {e}")

    def add_package(self, package_name: str, version: str, dependencies: List[str]):
        """Kay�tlara yeni bir paket ekler veya mevcut olan� g�nceller."""
        normalized_name = self._normalize_name(package_name)
        if not normalized_name:
            return

        package_data = self.registry["packages"].get(normalized_name, {})
        
        # Versiyon ge�mi�ini tut
        version_history = package_data.get("versions", [])
        if version not in version_history:
            version_history.append(version)

        self.registry["packages"][normalized_name] = {
            "current_version": version,
            "versions": version_history,
            "dependencies": [self._normalize_name(dep) for dep in dependencies],
            "last_installed_at": datetime.now().isoformat()
        }
        self.save()

    def get_package_info(self, package_name: str) -> Optional[Dict[str, Any]]:
        """Normalle�tirilmi� bir paket ad� i�in bilgi d�nd�r�r."""
        normalized_name = self._normalize_name(package_name)
        return self.registry["packages"].get(normalized_name)

class PipOutputAnalyzer:
    """'pip' komutunun ��kt�lar�n� analiz ederek hatalar� anlar, ba�ar�lar� kaydeder ve ��z�m �nerileri sunar."""
    def __init__(self, logger: AdvancedLogger):
        self.logger = logger
        # Ba�ar� desenleri
        self.success_dep_pattern = re.compile(r"Collecting\s+([a-zA-Z0-9_.-]+)")
        self.success_version_pattern = re.compile(r"Successfully installed\s+.*\s+([a-zA-Z0-9_.-]+)-([0-9a-zA-Z._+-]+)")

        # Geni�letilmi� Hata Desenleri
        self.error_patterns = {
            # Kategori: Paket Bulunamad�
            "no_matching_distribution": re.compile(r"ERROR: Could not find a version that satisfies the requirement ([^\s(]+)"),
            
            # Kategori: Derleme Hatalar� (Build Failures)
            "metadata_failed": re.compile(r"error: metadata-generation-failed|ERROR: Could not build wheels for ([^,]+?)(?:, which is required to install pyproject.toml-based projects)?$", re.MULTILINE),
            "missing_visual_cpp": re.compile(r"Microsoft Visual C\+\+ 14\.0 or greater is required", re.IGNORECASE),
            "cl_exe_failed": re.compile(r"error: command 'cl\.exe' failed", re.IGNORECASE),
            "missing_rust_compiler": re.compile(r"Could not find `rustc` in `PATH`", re.IGNORECASE),

            # Kategori: A� ve Ba�lant� Hatalar�
            "network_error": re.compile(r"WARNING: Retrying .* after connection broken by .*SSLError|ProxyError|ConnectTimeoutError", re.IGNORECASE),
            "http_error": re.compile(r"HTTP error 404|Could not fetch URL", re.IGNORECASE),

            # Kategori: �zin ve Ortam Hatalar�
            "permission_error": re.compile(r"ERROR: Could not install packages due to an OSError: \[Errno 13\] Permission denied", re.IGNORECASE),
            
            # Kategori: Ba��ml�l�k �ak��malar�
            "dependency_conflict": re.compile(r"ERROR: Cannot install .* because these package versions have conflicting dependencies."),
        }

    def analyze_success(self, output: str) -> Dict[str, Any]:
        """Ba�ar�l� bir pip ��kt�s�n� analiz eder ve kurulan paketler ile ba��ml�l�klar� d�nd�r�r."""
        dependencies = self.success_dep_pattern.findall(output)
        
        installed_packages = {}
        for match in self.success_version_pattern.finditer(output):
            installed_packages[match.group(1)] = match.group(2)

        if not installed_packages:
            self.logger.log("warning", "Pip ��kt�s�nda 'Successfully installed' deseni bulunamad�.")
            return {"main_package": None, "version": None, "dependencies": []}

        main_package_name = list(installed_packages.keys())[-1]
        main_package_version = installed_packages[main_package_name]

        cleaned_deps = [dep for dep in dependencies if dep.lower().replace('_', '-') != main_package_name.lower().replace('_', '-')]

        return {
            "main_package": main_package_name,
            "version": main_package_version,
            "dependencies": cleaned_deps
        }

    def analyze_failure(self, output: str) -> Dict[str, Any]:
        """
        Ba�ar�s�z bir pip ��kt�s�n� analiz eder ve bir eylem plan� d�nd�r�r.
        Eylem plan�: { "suggestion": { "action": "retry|abort|install_new", "new_args": [], "packages": [], "reason": "..." } }
        """
        self.logger.log("debug", f"Pip hata ��kt�s� analizi ba�lat�ld�. ��kt�:\n{output[:500]}...")

        # �zin Hatas� (En �ncelikli kontrol)
        if self.error_patterns["permission_error"].search(output):
            return {"suggestion": {"action": "abort", "reason": "Permission denied. Beti�i y�netici olarak �al��t�rmay� veya sanal bir ortam kullanmay� deneyin."}}

        # A� Hatalar�
        if self.error_patterns["network_error"].search(output):
            return {"suggestion": {"action": "retry", "reason": "A� ba�lant� sorunu tespit edildi.", "new_args": ["--timeout=100"]}}
        if self.error_patterns["http_error"].search(output):
            return {"suggestion": {"action": "retry", "reason": "HTTP hatas� (�rn. 404 Not Found) tespit edildi. Paket ad� veya versiyonu yanl�� olabilir.", "new_args": ["--timeout=100"]}}

        # Derleme Hatalar�
        if self.error_patterns["missing_visual_cpp"].search(output) or self.error_patterns["cl_exe_failed"].search(output):
            return {"suggestion": {"action": "abort", "reason": "Microsoft C++ Build Tools gerekli. https://visualstudio.microsoft.com/visual-cpp-build-tools/ adresinden y�kleyin."}}
        
        if self.error_patterns["missing_rust_compiler"].search(output):
            return {"suggestion": {"action": "abort", "reason": "Bu paket i�in Rust derleyicisi gerekli. https://www.rust-lang.org/tools/install adresinden y�kleyin."}}

        match = self.error_patterns["metadata_failed"].search(output)
        if match:
            package = match.group(1).strip() if match.group(1) else "bir paket"
            return {"suggestion": {"action": "install_new", "packages": ["setuptools", "wheel", "cython"], "reason": f"'{package}' i�in wheel derlenemedi. Gerekli derleme ara�lar� (setuptools, wheel) kurulacak."}}

        # Paket Bulunamad� Hatas�
        match = self.error_patterns["no_matching_distribution"].search(output)
        if match:
            package = match.group(1)
            return {"suggestion": {"action": "abort", "reason": f"'{package}' i�in uyumlu bir da��t�m bulunamad�. Paket ad�, versiyonu veya Python uyumlulu�unu kontrol edin."}}
            
        # Ba��ml�l�k �ak��mas�
        if self.error_patterns["dependency_conflict"].search(output):
             return {"suggestion": {"action": "abort", "reason": "Ba��ml�l�k �ak��mas� tespit edildi. Manuel m�dahale gerekli."}}

        # Varsay�lan Durum (Bilinmeyen Hata)
        return {"suggestion": {"action": "abort", "reason": "Bilinmeyen bir pip hatas� olu�tu. Detaylar i�in loglar� kontrol edin."}}

class ModuleSummaryGenerator:
    """Kurulum i�lemleri hakk�nda �zet ve istatistikler olu�turur.""" 
    def __init__(self, logger: AdvancedLogger, mode_manager: ModeManager):
        self.logger = logger
        self.mode_manager = mode_manager
        self.results: List[Dict[str, Any]] = []
        self.start_time = time.time()

    def add_module_status(self, package: str, status: str, duration: float, error: Optional[str] = None, reason: Optional[str] = None):
        """Bir mod�l�n kurulum sonucunu listeye ekler."""
        self.results.append({
            "package": package,
            "status": status,
            "duration": duration,
            "error": error,
            "reason": reason
        })

    def print_and_log_summary(self):
        """Tamamlanan t�m kurulumlar i�in son bir �zet olu�turur ve yazd�r�r."""
        if self.mode_manager.is_silent:
            return

        total_duration = time.time() - self.start_time
        successful_installs = [r for r in self.results if r["status"] in ["Ba�ar�l�", "Atland�"]]
        failed_installs = [r for r in self.results if r["status"] == "Ba�ar�s�z"]

        # Renkleri al (colorama y�kl� de�ilse bo� string d�nd�r)
        Fore = colorama.get('Fore') if colorama else type('d', (object,), {'__getattr__': lambda s, n: ''})()
        Style = colorama.get('Style') if colorama else type('d', (object,), {'__getattr__': lambda s, n: ''})()

        summary = [
            "\n" + "="*25 + " PDS-X Kurulum �zeti " + "="*25,
            f"Toplam {len(self.results)} paket i�lendi. Toplam S�re: {total_duration:.2f} saniye.",
            f"{Fore.GREEN}Ba�ar�l� Kurulumlar ({len(successful_installs)}):{Style.RESET_ALL}",
            "  " + (', '.join([r['package'] for r in successful_installs]) or "Yok"),
            f"{Fore.RED}Ba�ar�s�z Kurulumlar ({len(failed_installs)}):{Style.RESET_ALL}",
        ]

        if failed_installs:
            for r in failed_installs:
                reason_text = f" - Sebep: {r.get('reason', 'Bilinmiyor')}"
                summary.append(f"  - {Fore.YELLOW}{r['package']}{Style.RESET_ALL}{reason_text}")
        else:
            summary.append("  Yok")

        summary.append("="*70 + "\n")
        
        final_summary_text = "\n".join(summary)
        # Bu loglama hem dosyaya (JSON olmayan formatta) hem de konsola yazd�r�r.
        self.logger.log("info", final_summary_text)


class ResourceMonitor:
    """Sistem kaynaklar�n� (CPU, Bellek) izler."""
    def __init__(self, logger: AdvancedLogger):
        self.logger = logger
        self.psutil = get_psutil()
        self.running = False
        self.thread = None
        if not self.psutil:
            self.logger.log("warning", "psutil mod�l� bulunamad�. Kaynak izleme devre d���.")

    def start(self):
        if not self.psutil or self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._monitor, daemon=True)
        self.thread.start()
        self.logger.log("info", "Kaynak izleyici ba�lat�ld�.")

    def stop(self):
        self.running = False
        if self.thread and self.thread.is_alive():
            self.thread.join(timeout=2)
        self.logger.log("info", "Kaynak izleyici durduruldu.")

    def _monitor(self):
        while self.running:
            try:
                cpu_usage = self.psutil.cpu_percent(interval=5)
                memory_info = self.psutil.virtual_memory()
                self.logger.log("debug", f"Kaynak Kullan�m�: CPU: {cpu_usage}%, Bellek: {memory_info.percent}%")
            except Exception as e:
                self.logger.log("error", f"Kaynak izleme s�ras�nda hata: {e}")
                self.running = False # Hata durumunda d�ng�y� sonland�r

class AsyncDownloadManager:
    """Asenkron i�lemler i�in (�rn. wheel indirme) bir havuz y�netir."""
    def __init__(self, importer_instance: 'AutoImporter', max_workers: int = 4):
        self.importer = importer_instance
        self.logger = self.importer.logger
        self.executor = ThreadPoolExecutor(max_workers=max_workers)
        self.logger.log("info", f"Asenkron indirme y�neticisi {max_workers} i��i ile ba�lat�ld�.")

    def submit_download(self, package_spec: str):
        """Bir wheel indirme g�revini havuza g�nderir."""
        self.logger.log("info", f"'{package_spec}' i�in asenkron wheel indirme g�revi g�nderildi.")
        return self.executor.submit(self.importer.wheel_cache.download_wheel, package_spec)

class ScientificUtils:
    """Bilimsel ve a��r hesaplama gerektiren g�revler i�in ayr� bir i�lem havuzu y�netir."""
    def __init__(self, logger: AdvancedLogger, max_workers: int = 2):
        self.logger = logger
        self.process_executor = ProcessPoolExecutor(max_workers=max_workers)
        self.logger.log("info", f"Bilimsel hesaplama i�lem havuzu {max_workers} i��i ile ba�lat�ld�.")

    def submit_task(self, func, *args, **kwargs):
        """A��r bir g�revi i�lem havuzuna g�nderir."""
        self.logger.log("debug", f"'{func.__name__}' g�revi bilimsel i�lem havuzuna g�nderildi.")
        return self.process_executor.submit(func, *args, **kwargs)

class EnvManager:
    """Python ortam�n� ve pip/python yollar�n� y�netir."""
    def __init__(self, logger: AdvancedLogger):
        self.logger = logger
        self.python_path, self.pip_path = self._find_paths()
        self.logger.log("info", f"Python yolu: {self.python_path}")
        self.logger.log("info", f"Pip yolu: {self.pip_path}")

    def _find_paths(self) -> Tuple[Optional[Path], Optional[Path]]:
        """Mevcut Python ve pip y�r�t�lebilir dosyalar�n�n yollar�n� bulur."""
        python_path = Path(sys.executable)
        pip_path = python_path.parent / "pip.exe"
        if not pip_path.exists():
             pip_path = python_path.parent / "pip" # for non-windows
        
        if not python_path.exists():
            self.logger.log("error", "sys.executable yolu bulunamad�.")
            return None, None
        if not pip_path.exists():
            self.logger.log("warning", f"Pip y�r�t�lebilir dosyas� beklenen yolda bulunamad�: {pip_path}")
            # Alternatif bulma mekanizmas� eklenebilir
            return python_path, None
            
        return python_path, pip_path

class WheelCacheManager:
    """�ndirilen Python wheel dosyalar�n� y�netir."""
    def __init__(self, cache_dir: Path, logger: AdvancedLogger, env_manager: EnvManager):
        self.cache_dir = cache_dir / "wheels"
        self.logger = logger
        self.env_manager = env_manager
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.logger.log("info", f"Wheel cache y�neticisi ba�lat�ld�. Cache dizini: {self.cache_dir}")

    def find_wheel(self, package_spec: str) -> Optional[Path]:
        """Verilen bir paket i�in cache'de uygun bir wheel dosyas� arar."""
        package_name = package_spec.split("==")[0].split("[")[0].replace("-", "_")
        for wheel_file in self.cache_dir.glob(f"{package_name}-*.whl"):
            # Burada daha karma��k bir s�r�m kontrol� yap�labilir, �imdilik ilk buldu�unu d�nd�r�r.
            self.logger.log("info", f"Cache'de '{package_spec}' i�in uygun wheel bulundu: {wheel_file.name}")
            return wheel_file
        self.logger.log("info", f"Cache'de '{package_spec}' i�in wheel bulunamad�.")
        return None

    def download_wheel(self, package_spec: str) -> Optional[Path]:
        """Bir paketi sadece wheel olarak indirir ve cache'e kaydeder."""
        self.logger.log("info", f"'{package_spec}' i�in wheel indirme i�lemi ba�lat�l�yor...")
        cmd = [
            str(self.env_manager.pip_path),
            "wheel",
            "--no-deps",  # Sadece ana paketi indir, ba��ml�l�klar� de�il
            "-w", str(self.cache_dir),
            package_spec
        ]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, check=True, encoding='utf-8', errors='ignore')
            self.logger.log("debug", f"pip wheel ��kt�s�: {result.stdout}")
            # �ndirilen dosyan�n ad�n� ��kt�dan bulmak gerekir
            for line in result.stdout.splitlines():
                if "Successfully downloaded" in line:
                    # Bu ��kt� format� varsay�msald�r, pip versiyonuna g�re de�i�ebilir
                    downloaded_file_name = line.split(" ")[-1]
                    wheel_path = self.cache_dir / downloaded_file_name
                    if wheel_path.exists():
                        self.logger.log("info", f"'{package_spec}' ba�ar�yla indirildi ve cache'e eklendi: {wheel_path}")
                        return wheel_path
            # E�er yukar�daki mant�k �al��mazsa, indirilen dosyay� manuel bul
            return self.find_wheel(package_spec)

        except subprocess.CalledProcessError as e:
            self.logger.log("error", f"'{package_spec}' wheel indirilirken hata olu�tu: {e.stderr}")
            return None
        except Exception as e:
            self.logger.log("error", f"'{package_spec}' wheel indirilirken beklenmedik hata: {e}")
            return None

    def clear_cache(self):
        """T�m wheel cache'ini temizler."""
        self.logger.log("info", "Wheel cache temizleniyor...")
        for item in self.cache_dir.iterdir():
            item.unlink() if item.is_file() else shutil.rmtree(item)
        self.logger.log("info", "Wheel cache temizlendi.")

class KillSwitch:
    """Acil durdurma mekanizmas�."""
    def __init__(self, logger: AdvancedLogger):
        self.logger = logger
        self.is_active = False

    def activate(self):
        self.is_active = True
        self.logger.log("warning", "KILL SWITCH AKT�F! T�m operasyonlar durduruluyor.")

    def check(self):
        if self.is_active:
            raise InterruptedError("KillSwitch ile operasyon durduruldu.")

# --- YEN� AKILLI Y�NET�C�LER ---

class PipOptimizer:
    """
    Pip komutlar�n� optimize eder ve en iyi kurulum pratiklerini uygular.
    """
    def __init__(self, logger: AdvancedLogger):
        self.logger = logger
        self.base_args = [
            "--disable-pip-version-check",
            "--no-cache-dir",
            "--prefer-binary",
            "--upgrade-strategy", "eager"
        ]
        self.logger.log("info", f"Pip Optimizer ba�lat�ld�. Varsay�lan arg�manlar: {self.base_args}")

    def get_base_install_args(self) -> List[str]:
        """
        Kurulum i�in temel, optimize edilmi� pip arg�manlar�n� d�nd�r�r.
        """
        # Gelecekte buraya a� durumu, sistem y�k� gibi durumlara g�re
        # arg�manlar� dinamik olarak de�i�tirme mant��� eklenebilir.
        return self.base_args.copy()

class HeuristicManager:
    """
    Kurulum sonu�lar�ndan ��renerek gelecekteki kararlar� iyile�tiren sezgisel y�netici.
    'learned_dependencies.json' dosyas�n� y�netir.
    """
    def __init__(self, logger: AdvancedLogger, learned_deps_path: Path):
        self.logger = logger
        self.learned_deps_path = learned_deps_path
        self.learned_dependencies = self._load()

    def _load(self) -> Dict[str, List[str]]:
        """��renilmi� ba��ml�l�klar� dosyadan y�kler."""
        if not self.learned_deps_path.exists():
            self.logger.log("info", "��renilmi� ba��ml�l�klar dosyas� bulunamad�, yeni olu�turulacak.")
            return {}
        try:
            with open(self.learned_deps_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                # Basit bir do�rulama
                if "dependencies" in data and isinstance(data["dependencies"], dict):
                    self.logger.log("info", "��renilmi� ba��ml�l�klar ba�ar�yla y�klendi.")
                    return data["dependencies"]
                else:
                    self.logger.log("warning", "��renilmi� ba��ml�l�klar dosyas� ge�ersiz formatta. Yeni olu�turulacak.")
                    return {}
        except (json.JSONDecodeError, IOError) as e:
            self.logger.log("error", f"��renilmi� ba��ml�l�k dosyas� okunurken hata: {e}. Yeni olu�turulacak.")
            return {}

    def _save(self):
        """��renilmi� ba��ml�l�klar� dosyaya kaydeder."""
        try:
            with open(self.learned_deps_path, "w", encoding="utf-8") as f:
                # Dosyay� daha okunabilir bir formatta kaydet
                json.dump({"version": "1.1", "dependencies": self.learned_dependencies}, f, indent=4)
            self.logger.log("debug", f"��renilmi� ba��ml�l�klar �uraya kaydedildi: {self.learned_deps_path}")
        except IOError as e:
            self.logger.log("error", f"��renilmi� ba��ml�l�klar kaydedilirken hata: {e}")

    def learn_from_success(self, package_name: str, dependencies: List[str]):
        """
        Ba�ar�l� bir kurulumdan sonra ba��ml�l�klar� ��renir ve kaydeder.
        """
        # PEP 503 normalizasyonu
        normalized_package = package_name.lower().replace("_", "-")
        normalized_deps = sorted(list(set([d.lower().replace("_", "-") for d in dependencies])))

        # E�er yeni bilgi, eskisinden farkl�ysa g�ncelle
        if self.learned_dependencies.get(normalized_package) != normalized_deps:
            self.logger.log("info", f"Yeni ba��ml�l�k bilgisi ��renildi: '{normalized_package}' -> {normalized_deps}")
            self.learned_dependencies[normalized_package] = normalized_deps
            self._save()

    def get_learned_dependencies(self) -> Dict[str, List[str]]:
        """T�m ��renilmi� ba��ml�l�klar� d�nd�r�r."""
        return self.learned_dependencies.copy()


# --- YARDIMCI Y�NET�C� SINIFLARI (Referans Mimariden) ---

class GracefulShutdownManager:
    """Uygulaman�n d�zg�n bir �ekilde sonland�r�lmas�n� y�netir."""
    def __init__(self, logger):
        self.logger = logger
        self.tasks = []
        self.shutdown_requested = threading.Event()

    def register(self, task_name, stop_function):
        """Durdurulacak bir g�revi kaydeder."""
        self.tasks.append({'name': task_name, 'stop_func': stop_function})
        self.logger.log("debug", f"Kapatma g�revi kaydedildi: {task_name}")

    def shutdown(self):
        """T�m kay�tl� g�revleri s�rayla durdurur."""
        if self.shutdown_requested.is_set():
            return
        self.logger.log("info", "Graceful shutdown ba�lat�l�yor...")
        self.shutdown_requested.set()
        for task in reversed(self.tasks):
            try:
                self.logger.log("info", f"'{task['name']}' g�revi durduruluyor...")
                task['stop_func']()
            except Exception as e:
                # Hata nesnesini string'e �evirerek JSON serile�tirme sorununu ��z
                error_message = f"'{task['name']}' g�revi durdurulurken hata: {str(e)}"
                self.logger.log("error", error_message)
        self.logger.log("info", "Graceful shutdown tamamland�.")

class DependencyOptimizer:
    """
    Kurulum s�ras�n� optimize eder ve ba��ml�l�k grafi�ini analiz eder.
    'learned_dependencies.json' dosyas�n� kullanarak daha ak�ll� kararlar alabilir.
    """
    def __init__(self, logger: AdvancedLogger, dependency_registry: 'DependencyRegistry', heuristic_manager: 'HeuristicManager'):
        self.logger = logger
        self.dependency_registry = dependency_registry
        self.heuristic_manager = heuristic_manager
        self.graph = self._build_dependency_graph()

    def _build_dependency_graph(self) -> Dict[str, List[str]]:
        """
        Hem kay�tl� hem de ��renilmi� ba��ml�l�klardan birle�ik bir graf olu�turur.
        """
        graph = {}
        # ��renilmi� ba��ml�l�klar� HeuristicManager'dan al
        learned_deps = self.heuristic_manager.get_learned_dependencies()
        for package, deps in learned_deps.items():
            graph[package] = list(set(deps))

        # Kay�tl� (kurulu) ba��ml�l�klar� ekle/g�ncelle
        installed_packages = self.dependency_registry.registry.get("packages", {})
        for package, data in installed_packages.items():
            deps = data.get("dependencies", [])
            if package in graph:
                graph[package] = list(set(graph[package] + deps))
            else:
                graph[package] = list(set(deps))
        
        self.logger.log("debug", "Ba��ml�l�k grafi�i olu�turuldu.")
        return graph

    def get_optimized_order(self, packages_to_install: List[str]) -> List[str]:
        """
        Verilen paket listesi ve bilinen ba��ml�l�klar� i�in topolojik s�ralama kullanarak
        optimize edilmi� tam bir kurulum s�ras� d�nd�r�r.
        """
        self.logger.log("info", f"Kurulum s�ras� optimizasyonu ba�lat�ld� for: {packages_to_install}")

        # 1. Ad�m: Kurulacak t�m paketleri ve bunlar�n bilinen t�m alt ba��ml�l�klar�n� topla.
        all_packages_to_consider = set()
        q = deque()
        original_package_map = {}

        for pkg in packages_to_install:
            pkg_name_only = pkg.split("==")[0].split("[")[0]
            original_package_map[pkg_name_only] = pkg
            if pkg_name_only not in all_packages_to_consider:
                all_packages_to_consider.add(pkg_name_only)
                q.append(pkg_name_only)

        while q:
            package_name = q.popleft()
            dependencies = self.graph.get(package_name, [])
            for dep in dependencies:
                if dep not in all_packages_to_consider:
                    all_packages_to_consider.add(dep)
                    q.append(dep)

        # 2. Ad�m: Toplanan t�m paketler �zerinde topolojik s�ralama yap.
        sorted_order = []
        visited = set()
        
        for pkg_name in list(all_packages_to_consider):
            if pkg_name not in visited:
                if not self._topological_sort_util(pkg_name, visited, set(), sorted_order):
                    self.logger.log("warning", "Ba��ml�l�k grafi�inde d�ng� tespit edildi! Optimizasyon atlan�yor.")
                    return packages_to_install

        # 3. Ad�m: Son listeyi olu�tur, orijinal versiyonlar� geri y�kle.
        final_optimized_list = [original_package_map.get(p, p) for p in sorted_order]

        self.logger.log("info", f"Optimize edilmi� ve geni�letilmi� kurulum s�ras�: {final_optimized_list}")
        return final_optimized_list


    def _topological_sort_util(self, package: str, visited: set, recursion_stack: set, sorted_order: List[str]):
        """Topolojik s�ralama i�in yard�mc� DFS fonksiyonu."""
        visited.add(package)
        recursion_stack.add(package)

        # Bu paketin ba��ml�l�klar�n� gez
        dependencies = self.graph.get(package, [])
        for dep in dependencies:
            if dep not in visited:
                if not self._topological_sort_util(dep, visited, recursion_stack, sorted_order):
                    return False # D�ng� tespit edildi
            elif dep in recursion_stack:
                return False # D�ng� tespit edildi

        # T�m ba��ml�l�klar gezildikten sonra paketi listeye ekle
        if package not in sorted_order:
             sorted_order.append(package)
        recursion_stack.remove(package)
        return True

class ConflictManager:
    """Ba��ml�l�k �ak��malar�n� y�netir."""
    def __init__(self, logger, dependency_registry):
        self.logger = logger
        self.dependency_registry = dependency_registry
        self.packaging_libs = get_packaging_libs()

    def check_conflicts(self, package_requirement: str) -> Optional[str]:
        """Bir paketin mevcut ortamla �ak���p �ak��mad���n� kontrol eder."""
        self.logger.log("info", f"'{package_requirement}' i�in �ak��ma kontrol� yap�l�yor...")
        if not self.packaging_libs:
            self.logger.log("warning", "'packaging' k�t�phanesi bulunamad��� i�in �ak��ma kontrol� atlan�yor.")
            return None
        
        try:
            Requirement = self.packaging_libs["Requirement"]
            req = Requirement(package_requirement)
            
            # Mevcut kurulu paketlerle kar��la�t�r (basit kontrol)
            # Ger�ek bir implementasyon i�in 'pip' komutunun ��kt�s�n� analiz etmek gerekir.
            installed_packages = self.dependency_registry.registry.get("packages", {})
            for name, data in installed_packages.items():
                if name == req.name:
                    # Versiyon �ak��mas� kontrol�
                    # Bu k�s�m daha da geli�tirilebilir.
                    self.logger.log("warning", f"Potansiyel �ak��ma: '{req.name}' zaten kurulu (versiyon: {data.get('version', 'bilinmiyor')}).")

        except Exception as e:
            self.logger.log("error", f"Ge�ersiz gereksinim dizesi: '{package_requirement}'. Hata: {e}")
            return f"Ge�ersiz gereksinim: {package_requirement}"
            
        self.logger.log("info", f"'{package_requirement}' i�in �nemli bir �ak��ma bulunamad� (basit kontrol).")
        return None

class CodeAnalyzer:
    """
    Kaynak kodunu statik olarak analiz ederek import ifadelerini ve potansiyel ba��ml�l�klar� bulur.
    �nceki ModuleAnalyzer'�n yerini al�r ve AST (Abstract Syntax Tree) kullan�r.
    """
    def __init__(self, logger: AdvancedLogger):
        self.logger = logger

    def find_imports_from_source(self, file_path: Path) -> List[str]:
        """Bir Python kaynak dosyas�n� okur ve i�indeki t�m importlar� bulur."""
        if not file_path.exists() or not file_path.is_file():
            self.logger.log("warning", f"Kod analizi i�in kaynak dosya bulunamad�: {file_path}")
            return []
        
        self.logger.log("info", f"Kaynak dosya analiz ediliyor: {file_path}")
        try:
            with open(file_path, "r", encoding="utf-8") as f:
                source_code = f.read()
            tree = ast.parse(source_code, filename=file_path.name)
            
            imports = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    for alias in node.names:
                        # 'import a.b.c' durumunda en �st seviye paket 'a'd�r.
                        imports.add(alias.name.split('.')[0])
                elif isinstance(node, ast.ImportFrom):
                    # 'from a.b import c' durumunda, 'a'y� al.
                    # 'from . import x' gibi g�receli importlar� �imdilik atla (level > 0)
                    if node.level == 0 and node.module:
                        imports.add(node.module.split('.')[0])
            
            self.logger.log("info", f"'{file_path.name}' i�inde bulunan mod�ller: {list(imports)}")
            return list(imports)
            
        except (SyntaxError, UnicodeDecodeError) as e:
            self.logger.log("error", f"'{file_path.name}' dosyas� analiz edilirken hata olu�tu: {e}")
            return []
        except Exception as e:
            self.logger.log("error", f"'{file_path.name}' dosyas� okunurken beklenmedik hata: {e}")
            return []


class TerminalLogAnalyzer:
    """Terminal log dosyas�n� analiz ederek hatalar� ve eksik mod�lleri bulur."""
    def __init__(self, logger):
        self.logger = logger
        # �rnek: "ImportError: No module named 'requests'" veya "ModuleNotFoundError: No module named 'numpy'"
        self.import_error_pattern = re.compile(
            r"(?:ImportError|ModuleNotFoundError): No module named '([^']*)'"
        )

    def analyze_line(self, line: str) -> Optional[str]:
        """Tek bir log sat�r�n� analiz eder ve eksik mod�l ad�n� d�nd�r�r."""
        match = self.import_error_pattern.search(line)
        if match:
            missing_module = match.group(1)
            self.logger.log("info", f"Terminal logunda eksik mod�l tespit edildi: {missing_module}")
            return missing_module
        return None

class RealTimeLogMonitor:
    """Terminal log dosyas�n� ger�ek zamanl� olarak izler ve kurulumlar� tetikler."""
    def __init__(self, log_file: Path, analyzer: TerminalLogAnalyzer, importer: 'AutoImporter', logger: AdvancedLogger):
        self.log_file = log_file
        self.analyzer = analyzer
        self.importer = importer
        self.logger = logger
        self.running = False
        self.thread = threading.Thread(target=self._monitor, daemon=True)

    def start(self):
        """�zleme thread'ini ba�lat�r."""
        if not self.log_file.exists():
            self.logger.log("warning", f"�zlenecek log dosyas� bulunamad�: {self.log_file}. �zleyici ba�lat�lm�yor.")
            # Yine de dosyay� olu�turabiliriz.
            self.log_file.touch()
            
        self.running = True
        self.thread.start()
        self.logger.log("info", f"Ger�ek zamanl� log izleyici '{self.log_file}' i�in ba�lat�ld�.")

    def stop(self):
        """�zleme thread'ini durdurur."""
        self.running = False
        if self.thread.is_alive():
            self.thread.join(timeout=5)
        self.logger.log("info", "Ger�ek zamanl� log izleyici durduruldu.")

    def _monitor(self):
        """Log dosyas�n� izleyen ana d�ng�."""
        try:
            with open(self.log_file, 'r', encoding='utf-8') as f:
                f.seek(0, 2) # Dosyan�n sonuna git
                while self.running:
                    line = f.readline()
                    if not line:
                        time.sleep(0.5) # Yeni sat�r yoksa bekle
                        continue
                    
                    missing_module = self.analyzer.analyze_line(line)
                    if missing_module:
                        self.logger.log("info", f"�zleyici, '{missing_module}' i�in otomatik kurulumu tetikliyor.")
                        # Do�rudan kurulum kuyru�una ekle
                        self.importer.auto_install_package(missing_module)
        except FileNotFoundError:
            self.logger.log("warning", f"�zleme s�ras�nda log dosyas� kayboldu: {self.log_file}")
        except Exception as e:
            self.logger.log("error", f"Log izleme s�ras�nda kritik hata: {e}")


# --- Ak�ll� Kurulum Y�neticisi ---
class SmartInstallManager:
    """
    Kurulum s�recini ba�tan sona y�neten, di�er ak�ll� bile�enleri (Optimizer,
    ConflictManager vb.) kullanarak optimize edilmi� ve g�venli bir kurulum ak��� sa�layan s�n�f.
    """
    def __init__(self, packages_to_install: List[str], installer: 'AutoImporter'):
        """
        Args:
            packages_to_install: Kurulmas� istenen paketlerin listesi (�rn: ["requests", "pandas==1.5.3"]).
            installer: Ana AutoImporter �rne�i.
        """
        self.packages_to_install = packages_to_install
        self.installer = installer
        self.logger = self.installer.logger
        self.dependency_optimizer = self.installer.dependency_optimizer
        self.conflict_manager = self.installer.conflict_manager
        self.final_install_order: List[str] = []
        self.failed_packages: List[Dict[str, Any]] = []

    def _prepare_installation_plan(self):
        """Kurulum plan�n� haz�rlar: s�ralamay� optimize eder ve �ak��malar� kontrol eder."""
        self.logger.log("info", "Kurulum plan� haz�rlan�yor...")

        # 1. Ad�m: DependencyOptimizer kullanarak en iyi kurulum s�ras�n� al.
        # Bu metod, hem istenen paketleri hem de onlar�n bilinen t�m alt ba��ml�l�klar�n� i�eren
        # tam ve optimize edilmi� bir liste d�nd�r�r.
        self.final_install_order = self.dependency_optimizer.get_optimized_order(self.packages_to_install)
        self.logger.log("info", f"Optimize edilmi� kurulum s�ras�: {self.final_install_order}")

        # 2. Ad�m: Kuruluma ba�lamadan �nce potansiyel �ak��malar� kontrol et.
        # Bu, bariz s�r�m �ak��malar�n� �nceden tespit etmeye yard�mc� olabilir.
        for package_spec in self.final_install_order:
            conflict = self.conflict_manager.check_conflicts(package_spec)
            if conflict:
                self.logger.log("warning", f"Potansiyel �ak��ma uyar�s�: {conflict}. Kurulum denenecek ancak sorun ya�anabilir.")
                # Daha kat� bir modda burada kurulumu durdurabiliriz.
                # self.installer.kill_switch.activate()
                # return False
        return True

    def _execute_installation(self):
        """Haz�rlanan plana g�re kurulumu ger�ekle�tirir."""
        self.logger.log("info", "Optimize edilmi� plana g�re kurulum y�r�t�l�yor...")

        for package_spec in self.final_install_order:
            try:
                self.installer.kill_switch.check() # Her paketten �nce kill switch'i kontrol et
                
                # Ana installer'daki ak�ll� deneme mekanizmas�n� kullanarak paketi kur.
                # Bu fonksiyon ba�ar� durumunda True, ba�ar�s�zl�kta False d�ner.
                success = self.installer._install_package_with_retry(package_spec)
                
                if not success:
                    self.logger.log("error", f"'{package_spec}' paketi, t�m denemelere ra�men kurulamad�.")
                    self.failed_packages.append({"package": package_spec, "reason": "Kurulum denemeleri ba�ar�s�z oldu."})

            except InterruptedError as e:
                self.logger.log("critical", f"Kurulum acil durum anahtar� ile durduruldu: {e}")
                self.failed_packages.append({"package": package_spec, "reason": "KillSwitch aktif edildi."})
                break # D�ng�y� sonland�r
            except Exception as e:
                self.logger.log("critical", f"'{package_spec}' kurulumu s�ras�nda beklenmedik kritik hata: {e}", exc_info=True)
                self.failed_packages.append({"package": package_spec, "reason": str(e)})
                # Kritik hatada devam edip etmemek bir stratejiye ba�lanabilir. �imdilik devam ediyor.

    def _verify_environment(self):
        """Kurulum sonras� ortam�n sa�l���n� kontrol eder."""
        self.logger.log("info", "Kurulum sonras� ortam sa�l��� kontrol ediliyor...")
        self.conflict_manager.check_and_log_conflicts()


    def run(self):
        """Ak�ll� kurulum s�recini ba�tan sona �al��t�r�r."""
        self.logger.log("info", "?? Ak�ll� Kurulum Y�neticisi ba�lat�l�yor...")
        
        # 1. Plan� olu�tur
        if not self._prepare_installation_plan():
            self.logger.log("critical", "Kurulum plan� olu�turulamad��� i�in i�lem iptal edildi.")
            return

        # 2. Plan� uygula
        self._execute_installation()

        # 3. Ortam� do�rula
        self._verify_environment()

        # 4. Sonu�lar� raporla
        if self.failed_packages:
            self.logger.log("warning", f"Kurulum s�reci tamamland� ancak {len(self.failed_packages)} paket kurulamad�.")
            for failed in self.failed_packages:
                self.logger.log("warning", f"  - Ba�ar�s�z: {failed['package']} (Neden: {failed['reason']})")
        else:
            self.logger.log("info", "? Ak�ll� Kurulum Y�neticisi t�m g�revleri ba�ar�yla tamamlad�.")


# --- Ana AutoImporter S�n�f� ---
class AutoImporter:
    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(AutoImporter, cls).__new__(cls)
        return cls._instance

    def __init__(self, mode: str = 'NORMAL', monitor_terminal: bool = False, replay_args=None):
        if hasattr(self, 'initialized'):
            return

        # Modu ayarla
        try:
            op_mode = OperatingMode[mode.upper()]
        except KeyError:
            print(f"[PDS-X] UYARI: Ge�ersiz mod '{mode}'. 'NORMAL' moda ge�iliyor.")
            op_mode = OperatingMode.NORMAL
            
        global mode_manager
        self.mode_manager = ModeManager(op_mode)
        mode_manager = self.mode_manager

        # Temel bile�enleri ba�lat
        self.logger = AdvancedLogger()
        self.shutdown_manager = GracefulShutdownManager(self.logger)
        self.env_manager = EnvManager(logger=self.logger)
        self.dependency_registry = DependencyRegistry(self.logger)
        self.pip_output_analyzer = PipOutputAnalyzer(self.logger)
        self.wheel_cache = WheelCacheManager(CACHE_DIR, self.logger, self.env_manager)
        self.kill_switch = KillSwitch(self.logger)
        self.summary_generator = ModuleSummaryGenerator(self.logger, self.mode_manager)
        
        # Yeni ak�ll� y�neticiler
        self.pip_optimizer = PipOptimizer(self.logger)
        self.heuristic_manager = HeuristicManager(self.logger, BASE_DIR / "learned_dependencies.json")

        # Geli�mi� ve analitik bile�enler
        self.dependency_optimizer = DependencyOptimizer(self.logger, self.dependency_registry, self.heuristic_manager)
        self.conflict_manager = ConflictManager(self.logger, self.dependency_registry)
        self.code_analyzer = CodeAnalyzer(self.logger)
        self.resource_monitor = ResourceMonitor(self.logger)
        self.async_download_manager = AsyncDownloadManager(self)
        self.scientific_utils = ScientificUtils(self.logger)

        # Ger�ek zamanl� izleme bile�enleri
        self.terminal_log_analyzer = TerminalLogAnalyzer(self.logger)
        self.log_monitor = RealTimeLogMonitor(TERMINAL_LOG_FILE, self.terminal_log_analyzer, self, self.logger)

        # Durum nitelikleri
        self.lock = threading.Lock()
        self.installation_queue = queue.Queue()
        self.active_install_threads = 0
        self.installation_complete_event = threading.Event()
        self.installation_complete_event.set() # Ba�lang��ta tamamlanm�� durumda

        self.failed_packages = {}
        self.aliases = {}
        self.auto_install_enabled = True
        self.skip_modules = set(sys.builtin_module_names)
        
        self._prepare_aliases()
        
        # Kapatma y�neticisine g�revleri kaydet
        self.shutdown_manager.register("ResourceMonitor", self.resource_monitor.stop)
        self.shutdown_manager.register("LogMonitor", self.log_monitor.stop)
        self.shutdown_manager.register("AsyncDownloadManager", self.async_download_manager.executor.shutdown)
        self.shutdown_manager.register("ScientificUtils", self.scientific_utils.process_executor.shutdown)

        # Tee nesnelerini kapatma g�revini en sona ekle
        def close_tee_streams():
            if isinstance(sys.stdout, Tee):
                sys.stdout.close()
            if isinstance(sys.stderr, Tee):
                sys.stderr.close()
        self.shutdown_manager.register("TeeStreamCloser", close_tee_streams)


        if monitor_terminal:
            self.log_monitor.start()

        self.logger.log("info", f"AutoImporter v1.7.9.8 ba�lat�ld�. Mod: {op_mode.name}, Terminal �zleme: {'Aktif' if monitor_terminal else 'Pasif'}")
        self.initialized = True

    def check_package_installed(self, package_name: str) -> bool:
        """Bir paketin mevcut ortamda kurulu olup olmad���n� kontrol eder."""
        if not self.env_manager.pip_path:
            self.logger.log("warning", "Pip yolu bulunamad��� i�in paket kontrol� yap�lam�yor.")
            return False
        try:
            cmd = [str(self.env_manager.pip_path), "show", package_name]
            result = subprocess.run(cmd, capture_output=True, text=True, check=False, encoding='utf-8', errors='ignore')
            return result.returncode == 0
        except Exception as e:
            self.logger.log("error", f"'{package_name}' paketi kontrol edilirken hata: {e}")
            return False

    def auto_install_package(self, module_name: str, package_name: str = None, version: str = None):
        """
        Bir mod�l i�in kurulum s�recini ba�latan ana giri� noktas�.
        Kurulumu kuyru�a ekler ve i�lemeyi tetikler.
        """
        with self.lock:
            if not self.auto_install_enabled:
                self.logger.log("info", "Otomatik kurulum devre d���, i�lem atlan�yor.")
                return

            pkg_to_install = self._resolve_package_name(module_name, package_name)
            if version:
                pkg_to_install += f"=={version}"

            # Zaten kuyrukta veya hatal� olarak i�aretlenmi� mi kontrol et
            if pkg_to_install in list(self.installation_queue.queue) or pkg_to_install in self.failed_packages:
                self.logger.log("debug", f"Paket '{pkg_to_install}' zaten kuyrukta veya hatal� listesinde.")
                return

            self.logger.log("info", f"Otomatik kurulum i�in kuyru�a ekleniyor: {pkg_to_install}")
            self.installation_queue.put(pkg_to_install)
            self.installation_complete_event.clear() # Kurulum ba�lad���nda olay� temizle
        
        # Ayr� bir thread'de kuyru�u i�le, ana thread'i bloklama
        # E�er zaten bir i�leyici �al��m�yorsa yenisini ba�lat
        with self.lock:
            if self.active_install_threads == 0:
                self.active_install_threads += 1
                threading.Thread(target=self._process_installation_queue).start()


    def install_package(self, package: str, extra_args: List[str] = None) -> Dict[str, Any]:
        """
        Bir paketi kurar ve sonucu (ba�ar�, hata, ��kt�) bir s�zl�k olarak d�nd�r�r.
        Bu fonksiyon do�rudan _install_package_with_retry taraf�ndan kullan�l�r.
        """
        start_time = time.time()
        self.logger.log("info", f"'{package}' kurulumu ba�lat�l�yor... Arg�manlar: {extra_args}")
        
        try:
            self.kill_switch.check()

            # PipOptimizer'dan temel arg�manlar� al
            cmd = [str(self.env_manager.pip_path), "install"]
            cmd.extend(self.pip_optimizer.get_base_install_args())

            if extra_args:
                cmd.extend(extra_args)
            cmd.append(package)

            self.logger.log("debug", f"�al��t�r�lacak pip komutu: {' '.join(cmd)}")
            result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', errors='ignore')
            duration = time.time() - start_time

            output = result.stdout + "\n" + result.stderr
            
            return {
                "returncode": result.returncode,
                "output": output,
                "duration": duration,
                "package": package
            }

        except Exception as e:
            duration = time.time() - start_time
            self.logger.log("error", f"'{package}' kurulumunda beklenmedik bir alt i�lem hatas�: {e}")
            return {
                "returncode": -1,
                "output": str(e),
                "duration": duration,
                "package": package,
                "exception": e
            }

    def _install_package_with_retry(self, package: str, max_retries: int = 3) -> List[str]:
        """
        Bir paketi ak�ll� deneme mekanizmas� ile kurar.
        Ba�ar�s�z olursa ve yeni ba��ml�l�klar tespit ederse, bu ba��ml�l�klar�n bir listesini d�nd�r�r.
        """
        with self.lock:
            pkg_name_only = package.split("==")[0].split("[")[0]
            if self.check_package_installed(pkg_name_only):
                self.logger.log("info", f"Paket '{pkg_name_only}' zaten kurulu, kurulum atlan�yor.")
                self.summary_generator.add_module_status(pkg_name_only, "Atland�", 0, reason="Zaten y�kl�")
                return []

        retries = 0
        current_args = []
        new_dependencies_to_install = []
        package_to_install = package # Ba�lang��ta PyPI'dan al�nacak paket ad�
        duration = 0 # duration'� d�ng� d���nda tan�mla

        # 1. Ad�m: Cache'i kontrol et
        cached_wheel_path = self.wheel_cache.find_wheel(package)
        if cached_wheel_path:
            self.logger.log("info", f"'{package}' i�in cache kullan�l�yor: {cached_wheel_path}")
            package_to_install = str(cached_wheel_path)

        while retries < max_retries:
            self.logger.log("info", f"'{package_to_install}' kurulum denemesi {retries + 1}/{max_retries} (Arg�manlar: {current_args})")
            
            install_result = self.install_package(package_to_install, extra_args=current_args)
            output = install_result["output"]
            duration = install_result["duration"]
            pkg_name_only = package.split("==")[0].split("[")[0]

            if install_result["returncode"] == 0:
                self.logger.log("info", f"'{package}' ba�ar�yla kuruldu.")
                
                # Ba�ar�l� kurulumu analiz et ve kay�tlar� g�ncelle
                success_details = self.pip_output_analyzer.analyze_success(output)
                main_pkg = success_details.get("main_package") or pkg_name_only
                version = success_details.get("version")
                
                # Derin Ba��ml�l�k ��z�mlemesi: pip show ile ger�ek ba��ml�l�klar� al
                deep_deps = self._get_deep_dependencies(main_pkg)

                if main_pkg and version:
                    self.dependency_registry.add_package(main_pkg, version, deep_deps)
                    # Ba�ar�l� kurulumdan ��ren
                    self.heuristic_manager.learn_from_success(main_pkg, deep_deps)
                else:
                    # Analiz ba�ar�s�z olsa bile ana paketi kaydet
                    self.dependency_registry.add_package(pkg_name_only, "latest", deep_deps)
                    self.heuristic_manager.learn_from_success(pkg_name_only, deep_deps) # Ba��ml�l�k olmasa da ��ren

                # Ba�ar�l� kurulumdan sonra, e�er cache'den kurulmad�ysa, wheel'i cache'e ekle
                if not cached_wheel_path:
                    self.wheel_cache.download_wheel(package)

                reason = f"D�zeltildi ({current_args})" if retries > 0 else ""
                self.summary_generator.add_module_status(pkg_name_only, "Ba�ar�l�", duration, reason=reason)
                return new_dependencies_to_install # Ba�ar�l�, yeni ba��ml�l�k yoksa bo� liste d�ner

            # Kurulum ba�ar�s�z, analiz et
            self.logger.log("warning", f"'{package}' kurulumu ba�ar�s�z oldu. Hata analizi yap�l�yor...")
            failure_analysis = self.pip_output_analyzer.analyze_failure(output)
            suggestion = failure_analysis.get("suggestion", {})
            
            retries += 1

            if suggestion.get("action") == "retry":
                current_args.extend(suggestion.get("new_args", []))
                self.logger.log("info", f"Yeni deneme i�in arg�manlar g�ncellendi: {current_args}")
                # D�ng�ye devam et
            elif suggestion.get("action") == "install_new":
                new_deps = suggestion.get("packages", [])
                self.logger.log("info", f"Pip hatas�ndan yeni ba��ml�l�klar bulundu: {new_deps}. Ana kuruluma devam etmeden �nce bunlar denenecek.")
                new_dependencies_to_install.extend(new_deps)
                # Bu paketin denemesini sonland�r, �st d�ng� yenileri eklesin.
                return new_dependencies_to_install
            else: # "abort" veya bilinmeyen
                reason = suggestion.get("reason", "Bilinmiyor hata.")
                self.logger.log("error", f"'{package}' kurulumu kal�c� olarak ba�ar�s�z oldu. Sebep: {reason}")
                self.summary_generator.add_module_status(pkg_name_only, "Ba�ar�s�z", duration, error=output, reason=reason)
                raise PdsXInstallationError(f"'{package}' kurulumu ba�ar�s�z oldu: {reason}", "E009", {"package": package, "pip_error": output})

        # E�er d�ng� biterse ve hala ba�ar�l� olamad�ysa
        self.logger.log("error", f"'{package}' maksimum deneme say�s�na ula�t� ve kurulamad�.")
        self.summary_generator.add_module_status(pkg_name_only, "Ba�ar�s�z", duration, error=output, reason="Maksimum deneme say�s�na ula��ld�")
        raise PdsXInstallationError(f"'{package}' maksimum deneme say�s�na ula�t� ve kurulamad�.", "E011", {"package": package})

    def _get_deep_dependencies(self, package_name: str) -> List[str]:
        """
        'pip show' komutunu kullanarak bir paketin ger�ek ba��ml�l�klar�n� al�r.
        """
        if not self.env_manager.pip_path:
            self.logger.log("warning", "Pip yolu bulunamad��� i�in derin ba��ml�l�k kontrol� yap�lam�yor.")
            return []
        try:
            # Paket ad�ndan versiyon ve ekstralar� temizle
            clean_package_name = package_name.split("==")[0].split("[")[0]
            cmd = [str(self.env_manager.pip_path), "show", clean_package_name]
            result = subprocess.run(cmd, capture_output=True, text=True, check=True, encoding='utf-8', errors='ignore')
            
            dependencies = []
            for line in result.stdout.splitlines():
                if line.startswith("Requires:"):
                    # "Requires: numpy, pandas" -> ["numpy", "pandas"]
                    deps_str = line.replace("Requires:", "").strip()
                    if deps_str:
                        dependencies = [dep.strip() for dep in deps_str.split(",")]
                    break # Requires sat�r�n� bulduktan sonra d�ng�den ��k
            
            self.logger.log("info", f"'{clean_package_name}' i�in 'pip show' ile bulunan ba��ml�l�klar: {dependencies}")
            return dependencies
        except subprocess.CalledProcessError:
            self.logger.log("warning", f"'{clean_package_name}' i�in 'pip show' �al��t�r�lamad�. Paket bulunam�yor veya ba�ka bir hata var.")
            return []
        except Exception as e:
            self.logger.log("error", f"'{clean_package_name}' i�in derin ba��ml�l�klar al�n�rken hata: {e}")
            return []

    def install_from_list(self, packages: List[str]):
        """
        Verilen bir listedeki t�m paketleri toplu olarak kurar.
        Ak�ll� Kurulum Y�neticisi'ni kullan�r.
        """
        self.logger.log("info", f"Listedeki {len(packages)} paket i�in toplu kurulum ba�lat�l�yor.")
        if not packages:
            return

        self.logger.log("info", "Ak�ll� Kurulum Y�neticisi �al��t�r�l�yor...")
        # SmartInstallManager, bu toplu kurulum i�i i�in �zel olarak tasarlanm��t�r.
        smart_manager = SmartInstallManager(packages_to_install=packages, installer=self)
        try:
            # run() t�m ak�ll� kurulum ad�mlar�n� (planlama, y�r�tme, do�rulama) y�netir.
            smart_manager.run()
        except Exception as e:
            self.logger.log("error", f"Ak�ll� Kurulum Y�neticisi �al���rken bir hata olu�tu: {e}")
        finally:
            # Her toplu kurulumdan sonra bir �zet raporu olu�tur.
            self.summary_generator.print_and_log_summary()

    def install_from_file(self, file_path: str):
        """
        Bir dosyadan (requirements.txt gibi) paket listesini okur ve kurar.
        """
        self.logger.log("info", f"'{file_path}' dosyas�ndan paketler okunuyor...")
        try:
            p = Path(file_path)
            if not p.is_file():
                raise PdsXNotFoundError(f"Gereksinim dosyas� bulunamad� veya bir dizin: {file_path}", "E013")
            
            with open(p, "r", encoding="utf-8") as f:
                # Yorumlar� (# ile ba�layan) ve bo� sat�rlar� atla
                packages = [
                    line.strip() for line in f 
                    if line.strip() and not line.strip().startswith("#")
                ]
            
            if packages:
                self.logger.log("info", f"'{file_path}' dosyas�ndan {len(packages)} paket bulundu. Kurulum ba�lat�l�yor.")
                self.install_from_list(packages)
            else:
                self.logger.log("info", "Gereksinim dosyas�nda kurulacak paket bulunamad�.")

        except Exception as e:
            self.logger.log("error", f"'{file_path}' dosyas�ndan kurulum yap�l�rken hata: {e}")

    def import_and_install(self, module_name: str, package_name: str = None, version: str = None):
        """
        Bir mod�l� i�e aktarmay� dener, ba�ar�s�z olursa otomatik olarak kurar.
        Bu, PDS-X ana d�ng�s�nden �a�r�lacak ana fonksiyondur.
        """
        try:
            # 1. Ad�m: Mod�l� do�rudan i�e aktarmay� dene
            self.logger.log("info", f"Mod�l i�e aktar�l�yor: {module_name}")
            return importlib.import_module(module_name)
        except (ImportError, ModuleNotFoundError) as e:
            self.logger.log("warning", f"Mod�l '{module_name}' bulunamad�. Hata: {e}. Otomatik kurulum denenecek.")
            
            if not self.auto_install_enabled:
                self.logger.log("warning", "Otomatik kurulum devre d��� oldu�undan mod�l y�klenemedi.")
                raise # Kurulum kapal�ysa hatay� tekrar y�kselt

            # 2. Ad�m: Kurulumu tetikle
            try:
                # auto_install_package kurulumu kuyru�a ekler ve arka planda ba�lat�r.
                self.auto_install_package(module_name, package_name, version)
                # Kurulumun tamamlanmas�n� bekle
                self.wait_for_installs_to_complete()

                # 3. Ad�m: Kurulumdan sonra tekrar i�e aktarmay� dene
                self.logger.log("info", f"Kurulum sonras� '{module_name}' tekrar i�e aktar�l�yor.")
                return importlib.import_module(module_name)
            except Exception as install_error:
                pkg_to_install = self._resolve_package_name(module_name, package_name)
                self.logger.log("error", f"'{module_name}' mod�l� kurulduktan sonra bile i�e aktar�lamad�: {install_error}")
                raise PdsXImportError(
                    f"Mod�l '{module_name}' (paket: {pkg_to_install}) kurulmaya �al���ld� ancak sonras�nda i�e aktar�lamad�.",
                    "E012",
                    {"module": module_name, "package": pkg_to_install, "original_error": str(install_error)}
                ) from install_error

    def trigger_task(self, task: Dict[str, Any]):
        """PDS-X gibi harici sistemlerden gelen g�revleri i�lemek i�in programatik API."""
        task_name = task.get("task")
        payload = task.get("payload")
        self.logger.log("info", f"Harici g�rev al�nd�: {task_name}")

        if task_name == "install_list":
            if isinstance(payload, list):
                self.install_from_list(payload)
            else:
                self.logger.log("error", f"install_list g�revi i�in payload liste olmal�, al�nd�: {type(payload)}")
        elif task_name == "install_file":
            if isinstance(payload, str):
                self.install_from_file(payload)
            else:
                self.logger.log("error", f"install_file g�revi i�in payload dosya yolu (str) olmal�, al�nd�: {type(payload)}")
        else:
            self.logger.log("warning", f"Bilinmeyen g�rev al�nd�: {task_name}")

    def _process_installation_queue(self):
        """Kurulum kuyru�unu i�ler."""
        try:
            processed_in_this_run = set()
            while not self.installation_queue.empty():
                package = self.installation_queue.get()
                if package in processed_in_this_run:
                    self.installation_queue.task_done()
                    continue
                processed_in_this_run.add(package)

                try:
                    # install_package yerine _install_package_with_retry kullan
                    new_deps = self._install_package_with_retry(package)
                    if new_deps:
                        self.logger.log("info", f"'{package}' i�in yeni ba��ml�l�klar eklendi: {new_deps}")
                        for dep in new_deps:
                            if dep not in processed_in_this_run:
                                # Yeni bulunan ba��ml�l�klar� kuyru�un ba��na ekle
                                # Bu, deque kullan�larak daha verimli hale getirilebilir
                                q_items = list(self.installation_queue.queue)
                                self.installation_queue = queue.Queue()
                                self.installation_queue.put(dep)
                                for item in q_items:
                                    self.installation_queue.put(item)

                except Exception as e:
                    self.logger.log("error", f"Kuyruk i�lenirken '{package}' kurulamad�: {e}")
                    # Hatal� paketi tekrar denemek i�in i�aretle
                    self.failed_packages[package.split("==")[0].split("[")[0]] = str(e)
                finally:
                    self.installation_queue.task_done()
        finally:
            # ��lem bitti�inde, olay� ayarla ve aktif thread say�s�n� d���r
            with self.lock:
                self.active_install_threads -= 1
                if self.installation_queue.empty():
                    self.installation_complete_event.set()


    def wait_for_installs_to_complete(self, timeout: Optional[float] = None):
        """T�m kurulum i�lemlerinin tamamlanmas�n� bekler."""
        self.logger.log("info", "Beklemedeki t�m kurulum g�revlerinin tamamlanmas� bekleniyor...")
        self.installation_complete_event.wait(timeout)
        if not self.installation_complete_event.is_set():
            self.logger.log("warning", "Bekleme s�resi a��ld�, ancak kurulumlar hala devam ediyor olabilir.")
        else:
            self.logger.log("info", "T�m kurulum g�revleri tamamland�.")

    def _resolve_package_name(self, module_name: str, package_name: Optional[str] = None) -> str:
        """Mod�l ad�ndan paket ad�n� ��zer (alias'lar� kullanarak)."""
        if package_name:
            return package_name
        # Alias kontrol�
        if module_name in self.aliases:
            return self.aliases[module_name]
        # Genel kural
        return module_name.replace('_', '-')

    def _prepare_aliases(self):
        """Kod i�indeki ve harici dosyadan takma adlar� y�kler."""
        # Kod i�i varsay�lanlar
        self.aliases = {
            "bs4": "beautifulsoup4",
            "cv2": "opencv-python",
            "skimage": "scikit-image",
            "sklearn": "scikit-learn",
            "yaml": "PyYAML",
        }
        # Harici dosyadan y�kle
        if ALIAS_FILE.exists():
            try:
                with open(ALIAS_FILE, "r", encoding="utf-8") as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith("#") and ":" in line:
                            alias, package = line.split(":", 1)
                            self.aliases[alias.strip()] = package.strip()
                self.logger.log("info", f"Harici alias dosyas�ndan {len(self.aliases)} takma ad y�klendi.")
            except Exception as e:
                self.logger.log("error", f"Alias dosyas� ({ALIAS_FILE}) okunurken hata: {e}")
        else:
            self.logger.log("info", "Harici alias dosyas� bulunamad�, varsay�lanlar kullan�l�yor.")

    def shutdown(self):
        """T�m arkaplan i�lemlerini durdurur ve �zeti yazd�r�r."""
        self.logger.log("info", "AutoImporter kapat�l�yor...")
        self.shutdown_manager.shutdown()
        
        self.summary_generator.print_and_log_summary()
        
        # Tee nesnelerini kapatma i�lemi art�k shutdown_manager taraf�ndan y�netiliyor.
        # if isinstance(sys.stdout, Tee):
        #     sys.stdout.close()
        # if isinstance(sys.stderr, Tee):
        #     sys.stderr.close()

# --- Ana �al��t�rma Blo�u ---
def main():
    parser = argparse.ArgumentParser(description="PDS-X Ak�ll� Mod�l Y�kleyici")
    parser.add_argument(
        "--mode", 
        type=str, 
        choices=[e.name for e in OperatingMode], 
        default="NORMAL",
        help="�al��ma modunu ayarlar (NORMAL, SUPPRESSED, SILENT, TOTAL_SILENT)."
    )
    parser.add_argument(
        "--monitor",
        action="store_true",
        help="Terminal loglar�n� ger�ek zamanl� olarak izleyerek otomatik kurulumu tetikler."
    )
    parser.add_argument(
        "--install-file",
        type=str,
        help="Belirtilen dosyadan (requirements.txt gibi) paketleri toplu olarak kurar."
    )
    parser.add_argument(
        "--install-list",
        nargs='+',
        help="Komut sat�r�ndan verilen paket listesini toplu olarak kurar."
    )
    parser.add_argument(
        "module", 
        nargs='?', 
        help="��e aktar�lacak ve gerekirse kurulacak olan mod�l�n ad�."
    )
     
    args = parser.parse_args()

    # Tee nesnelerini ba�latmadan �nce log dosyas�n� temizle
    if TERMINAL_LOG_FILE.exists():
        try:
            TERMINAL_LOG_FILE.write_text('')  # Log dosyas�n� temizle
        except Exception as e:
            print(f"[PDS-X] Uyar�: Terminal log dosyas� temizlenemedi: {e}")

    # Tee nesnelerini ba�lat
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    stdout_tee = Tee(original_stdout, TERMINAL_LOG_FILE)
    stderr_tee = Tee(original_stderr, TERMINAL_LOG_FILE)

    try:
        # AutoImporter �rne�ini ba�lat
        importer = AutoImporter(mode=args.mode, monitor_terminal=args.monitor)
        
        # Komut sat�r� se�eneklerini i�le
        if args.install_file:
            importer.install_from_file(args.install_file)
        if args.install_list:
            importer.install_from_list(args.install_list)
        if args.module:
            importer.import_and_install(args.module)
        
        # Kurulumlar tamamlanana kadar bekle ve ard�ndan kapat
        importer.wait_for_installs_to_complete()
        importer.shutdown()
        
    except Exception as e:
        print(f"{colorama['Fore'].RED}Kritik bir hata olu�tu: {e}{colorama['Style'].RESET_ALL}")
    finally:
        # AutoImporter'�n kapatma fonksiyonunu �a��rarak kaynaklar� serbest b�rak
        if 'importer' in locals() and importer:
            importer.shutdown()
        else:
            # E�er importer hi� ba�lat�lamad�ysa, Tee'leri manuel kapat
            if isinstance(sys.stdout, Tee):
                sys.stdout.close()
            if isinstance(sys.stderr, Tee):
                sys.stderr.close()

# Ana blok
if __name__ == '__main__':
    main()
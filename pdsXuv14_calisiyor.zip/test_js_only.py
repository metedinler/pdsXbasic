#!/usr/bin/env python3
"""
Gerçek JavaScript Test - Python olmayan program
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from program_manager import MultiLineProgramManager

def test_only_javascript():
    """Sadece JavaScript programı test et"""
    print("🧪 Sadece JavaScript Program Testi")
    print("=" * 40)
    
    manager = MultiLineProgramManager()
    
    # Sadece JavaScript programı oluştur
    print("📝 Sadece JavaScript programı oluşturuluyor...")
    manager.start_program("PROGRAM onlyjs.js")
    manager.add_line("console.log('Bu sadece JavaScript!');")
    manager.add_line("let x = 42;")
    manager.add_line("console.log('Sonuç:', x);")
    manager.end_program()
    
    # Çalıştırmaya çalış
    print("\n🚀 JavaScript programını çalıştırmaya çalışıyoruz:")
    success = manager.run_program("onlyjs")
    
    print(f"\nSonuç: {'✅ Başarılı' if success else '❌ Başarısız'}")

if __name__ == "__main__":
    test_only_javascript()

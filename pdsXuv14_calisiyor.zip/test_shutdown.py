#!/usr/bin/env python3
"""
AutoImporter Graceful Shutdown Test
"""

import sys
import time
import threading

try:
    from auto_importer import AutoImporter
    print("[TEST] ✅ AutoImporter modülü başarıyla import edildi")
    
    # AutoImporter instance oluştur
    ai = AutoImporter()
    print("[TEST] ✅ AutoImporter instance oluşturuldu")
    
    # AutoImporter'ın mevcut durumunu kontrol et
    print(f"[TEST] 📊 AutoImporter running: {ai.running}")
    print(f"[TEST] 📊 Thread pool mevcut: {hasattr(ai, 'thread_pool')}")
    print(f"[TEST] 📊 Realtime monitor mevcut: {hasattr(ai, 'realtime_monitor')}")
    
    # Kısa bir süre çalıştır (simulate normal operation)
    print("[TEST] 🏃 AutoImporter normal çalışmayı simüle ediyor...")
    ai.running = True
    time.sleep(2)
    
    # Graceful shutdown test
    print("[TEST] 🛑 Graceful shutdown test başlatılıyor...")
    
    if hasattr(ai, 'shutdown'):
        ai.shutdown()
        print("[TEST] ✅ shutdown() metodu başarıyla çalıştırıldı")
    else:
        print("[TEST] ❌ shutdown() metodu bulunamadı")
    
    # Final durum kontrol
    print(f"[TEST] 📊 Final AutoImporter running: {ai.running}")
    print("[TEST] ✅ Test tamamlandı")
    
except ImportError as e:
    print(f"[TEST] ❌ AutoImporter import hatası: {e}")
except Exception as e:
    print(f"[TEST] ❌ Test hatası: {e}")
    import traceback
    traceback.print_exc()

#!/usr/bin/env python3
"""Test PDS-X komut öğrenme"""

import os
import sys
from pathlib import Path

def test_pdsx_detection():
    """Test PDS-X dosya tespiti"""
    print("[TEST] PDS-X dosyaları aranıyor...")
    
    # Workspace'te PDS-X dosyalarını ara
    pdsx_files = [
        "pdsx.py", "pdsxu_v14.py", "pdsxeu_v14.py", "core.py", 
        "main.py", "pdsx_main.py", "pdsx_interpreter.py"
    ]
    
    found_files = []
    for file in pdsx_files:
        if Path(file).exists():
            found_files.append(f"python {file}")
            print(f"[TEST] ✅ Bulundu: {file}")
    
    if not found_files:
        print("[TEST] ❌ Hiç PDS-X dosyası bulunamadı")
        # Manuel komut al
        print("[TEST] Manuel komut girişi:")
        print("[TEST] Örnek: python pdsx.py, python pdsxu_v14.py")
    else:
        print(f"[TEST] 🎯 Toplam {len(found_files)} PDS-X dosyası bulundu")
        for cmd in found_files:
            print(f"[TEST]   • {cmd}")
    
    return found_files

if __name__ == "__main__":
    print("[TEST] PDS-X tespit sistemi başlatılıyor...")
    commands = test_pdsx_detection()
    print(f"[TEST] Sonuç: {len(commands)} komut tespit edildi")

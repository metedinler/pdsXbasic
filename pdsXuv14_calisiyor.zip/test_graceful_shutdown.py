#!/usr/bin/env python3
"""
AutoImporter Graceful Shutdown Manual Test
Bu dosya AutoImporter'ın graceful shutdown özelliğini manuel test eder.
"""

import sys
import os

# PDS-X dizinini path'e ekle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_graceful_shutdown():
    """AutoImporter graceful shutdown test"""
    print("\n" + "="*60)
    print("     AutoImporter Graceful Shutdown Test")
    print("="*60)
    
    try:
        # AutoImporter import test
        print("\n1. AutoImporter import testi...")
        from auto_importer import AutoImporter
        print("   ✅ AutoImporter başarıyla import edildi")
        
        # Instance oluşturma
        print("\n2. AutoImporter instance oluşturuluyor...")
        ai = AutoImporter()
        print("   ✅ AutoImporter instance başarıyla oluşturuldu")
        
        # Mevcut özellikler kontrolü
        print("\n3. Graceful shutdown özellikleri kontrol ediliyor...")
        features = {
            'shutdown metodu': hasattr(ai, 'shutdown'),
            'cleanup_on_shutdown metodu': hasattr(ai, 'cleanup_on_shutdown'),
            'thread_pool': hasattr(ai, 'thread_pool'),
            'realtime_monitor': hasattr(ai, 'realtime_monitor'),
            'running durumu': hasattr(ai, 'running')
        }
        
        for feature, available in features.items():
            status = "✅" if available else "❌"
            print(f"   {status} {feature}")
        
        # Graceful shutdown test
        print("\n4. Graceful shutdown test başlatılıyor...")
        ai.running = True  # Simulate running state
        print("   🏃 AutoImporter çalışma durumu simüle edildi")
        
        if hasattr(ai, 'shutdown'):
            print("   🛑 Graceful shutdown başlatılıyor...")
            ai.shutdown()
            print("   ✅ Graceful shutdown tamamlandı")
            
            # Final durum kontrolü
            print(f"   📊 Final running durumu: {ai.running}")
        else:
            print("   ❌ shutdown() metodu bulunamadı")
        
        print("\n5. Test Sonucu:")
        if all(features.values()):
            print("   ✅ TÜM ÖZELLİKLER MEVCUT - Graceful shutdown sistemi tam!")
        else:
            missing = [k for k, v in features.items() if not v]
            print(f"   ⚠️ Eksik özellikler: {missing}")
        
    except Exception as e:
        print(f"   ❌ Test hatası: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "="*60)
    print("Test tamamlandı!")
    print("="*60)

if __name__ == "__main__":
    test_graceful_shutdown()

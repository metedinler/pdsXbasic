"""
Çok satırlı program yazma ve yönetme sistemi - Temiz versiyon
"""

import re
import time
import json
import os
import sys
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional, List

# PDS-X BASIC Gerçek Interpreter import
try:
    # Gerçek PDS-X BASIC interpreter'ını kullan
    from pdsXuv14 import PdsXInterpreter  # Ana PDS-X interpreter
    REAL_PDSX_AVAILABLE = True
    print("[PDS-X] ✅ Gerçek PDS-X BASIC interpreter yüklendi")
except ImportError:
    try:
        # Fallback: command_executor'ı doğrudan kullan
        from command_executor import CommandExecutor
        REAL_PDSX_AVAILABLE = True
        print("[PDS-X] ✅ PDS-X Command Executor yüklendi")
    except ImportError:
        print("[PDS-X] ❌ PDS-X BASIC interpreter bulunamadı!")
        REAL_PDSX_AVAILABLE = False


class MultiLineProgramManager:
    """
    Çok satırlı program yazma ve yönetme sistemi
    
    Desteklenen format:
    PROGRAM <program_name>.<extension>
    <kod satırları>
    END PROGRAM
    
    Desteklenen uzantılar:
    - .basX  : PDS-X BASIC (varsayılan)
    - .libx  : LibX library pseudocode  
    - .pdsx  : PDS-X komutları ve makrolar
    - .py    : Python
    - .js    : JavaScript
    - .sql   : SQL queries
    """
    
    def __init__(self, programs_dir: Optional[str] = None):
        self.programs = {}  # Program ismi -> {extension -> {'code': str, 'metadata': dict}}
        self.programs_dir = Path(programs_dir or "programs")
        self.programs_dir.mkdir(exist_ok=True)
        
        # Desteklenen uzantılar ve özellikleri
        self.supported_extensions = {
            '.basx': {'name': 'PDS-X BASIC', 'executable': True, 'encrypt': True, 'compress': True},
            '.libx': {'name': 'LibX Library', 'executable': True, 'encrypt': True, 'compress': True},
            '.pdsx': {'name': 'PDS-X Commands', 'executable': True, 'encrypt': True, 'compress': True},
            '.py': {'name': 'Python', 'executable': True, 'encrypt': False, 'compress': False},
            '.js': {'name': 'JavaScript', 'executable': True, 'encrypt': False, 'compress': False},
            '.sql': {'name': 'SQL Queries', 'executable': False, 'encrypt': False, 'compress': False},
            '.txt': {'name': 'Plain Text', 'executable': False, 'encrypt': False, 'compress': False}
        }
        
        self.current_program = None
        self.current_code_lines = []
        self.in_program_mode = False
        
        # Şifreleme ve sıkıştırma için
        self.compression_enabled = True
        self.encryption_enabled = True
        
        # PDS-X BASIC Interpreter - gerçek interpreter
        if REAL_PDSX_AVAILABLE:
            try:
                # Ana PDS-X interpreter'ını kullanmaya çalış
                self.pdsx_interpreter = PdsXInterpreter()
                print("[PDS-X] ✅ Ana PDS-X interpreter başlatıldı")
            except:
                # Fallback: command executor
                self.pdsx_interpreter = None
                print("[PDS-X] ✅ PDS-X Command Executor hazır")
        else:
            self.pdsx_interpreter = None
            print("[PDS-X] ❌ PDS-X BASIC interpreter kullanılamıyor")
        
    def start_program(self, program_declaration: str) -> bool:
        """
        Program yazma modunu başlat
        
        Format: PROGRAM <n>.<extension>
        Örnek: PROGRAM hello.basX
               PROGRAM mylib.libx
               PROGRAM scripts.pdsx
        """
        try:
            # Program deklarasyonunu parse et
            match = re.match(r'PROGRAM\s+([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z]+)?)', program_declaration.strip())
            if not match:
                print("[PDS-X] ❌ Geçersiz program deklarasyonu. Format: PROGRAM <n>.<extension>")
                return False
            
            program_name_with_ext = match.group(1)
            
            # Uzantı kontrolü
            if '.' in program_name_with_ext:
                program_name, extension = program_name_with_ext.rsplit('.', 1)
                extension = '.' + extension.lower()
            else:
                program_name = program_name_with_ext
                extension = '.basx'  # Varsayılan uzantı
            
            # Desteklenen uzantı kontrolü
            if extension not in self.supported_extensions:
                print(f"[PDS-X] ⚠️ Desteklenmeyen uzantı: {extension}")
                print(f"[PDS-X] 📋 Desteklenen uzantılar: {', '.join(self.supported_extensions.keys())}")
                return False
            
            # Program modu başlat
            self.current_program = {
                'name': program_name,
                'extension': extension,
                'full_name': f"{program_name}{extension}"
            }
            self.current_code_lines = []
            self.in_program_mode = True
            
            ext_info = self.supported_extensions[extension]
            print(f"[PDS-X] 📝 Program yazma modu başlatıldı: {self.current_program['full_name']}")
            print(f"[PDS-X] 🔤 Dil: {ext_info['name']}")
            print(f"[PDS-X] 💾 Şifreleme: {'✅' if ext_info['encrypt'] else '❌'}")
            print(f"[PDS-X] 🗜️ Sıkıştırma: {'✅' if ext_info['compress'] else '❌'}")
            print(f"[PDS-X] ⚡ Çalıştırılabilir: {'✅' if ext_info['executable'] else '❌'}")
            print(f"[PDS-X] 📋 'END PROGRAM' yazarak tamamlayın")
            
            return True
            
        except Exception as e:
            print(f"[PDS-X] ❌ Program başlatma hatası: {e}")
            return False
    
    def add_line(self, line: str) -> bool:
        """Program modunda satır ekle"""
        if not self.in_program_mode:
            return False
        self.current_code_lines.append(line)
        return True
        
    def end_program(self) -> bool:
        """Program yazma modunu sonlandır ve kaydet"""
        if not self.in_program_mode or self.current_program is None:
            return False
        
        # Program kodunu birleştir
        code = '\n'.join(self.current_code_lines)
        
        # Program bilgilerini kaydet
        program_key = self.current_program['name']
        if program_key not in self.programs:
            self.programs[program_key] = {}
        
        self.programs[program_key][self.current_program['extension']] = {
            'code': code,
            'metadata': {
                'created': time.time(),
                'lines': len(self.current_code_lines),
                'size': len(code)
            }
        }
        
        # Dosyaya kaydet
        try:
            self._save_program_to_file(program_key, self.current_program['extension'], code)
        except Exception as e:
            print(f"[PDS-X] ⚠️ Dosya kaydetme hatası: {e}")
        
        print(f"[PDS-X] ✅ Program kaydedildi: {self.current_program['full_name']}")
        print(f"[PDS-X] 📊 {len(self.current_code_lines)} satır, {len(code)} karakter")
        
        # Modu sıfırla
        self.in_program_mode = False
        self.current_program = None
        self.current_code_lines = []
        
        return True
        
    def _get_all_programs(self) -> dict:
        """Tüm programları döndür"""
        return self.programs.copy()
        
    def _get_program_content(self, name: str, extension: str) -> str:
        """Program içeriğini döndür"""
        if name in self.programs and extension in self.programs[name]:
            return self.programs[name][extension]['code']
        return ""
        
    def _compress_content(self, content: str) -> bytes:
        """İçeriği sıkıştır"""
        import gzip
        return gzip.compress(content.encode('utf-8'))
        
    def _decompress_content(self, compressed: bytes) -> str:
        """Sıkıştırılmış içeriği aç"""
        import gzip
        return gzip.decompress(compressed).decode('utf-8')
        
    def _encrypt_content(self, content: str, password: str) -> bytes:
        """İçeriği şifrele (basit XOR)"""
        content_bytes = content.encode('utf-8')
        password_bytes = password.encode('utf-8')
        result = bytearray()
        for i, byte in enumerate(content_bytes):
            result.append(byte ^ password_bytes[i % len(password_bytes)])
        return bytes(result)
        
    def _decrypt_content(self, encrypted: bytes, password: str) -> str:
        """Şifrelenmiş içeriği çöz"""
        password_bytes = password.encode('utf-8')
        result = bytearray()
        for i, byte in enumerate(encrypted):
            result.append(byte ^ password_bytes[i % len(password_bytes)])
        return result.decode('utf-8')
        
    def _save_program_to_file(self, name: str, extension: str, code: str):
        """Programı dosyaya kaydet"""
        filename = f"{name}{extension}"
        filepath = self.programs_dir / filename
        
        # Basit metin dosyası olarak kaydet
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(code)
            
    def list_programs(self, filter_ext: Optional[str] = None) -> None:
        """Tüm programları listele"""
        if not self.programs:
            print("[PDS-X] 📋 Henüz program yok")
            return
        
        print("[PDS-X] 📋 Kaydedilmiş Programlar:")
        print("-" * 50)
        
        for prog_name, extensions in self.programs.items():
            for ext, data in extensions.items():
                if filter_ext is None or ext == filter_ext:
                    metadata = data['metadata']
                    lang = self.supported_extensions.get(ext, {}).get('name', 'Unknown')
                    print(f"  📄 {prog_name}{ext} ({lang})")
                    print(f"      📊 {metadata['lines']} satır, {metadata['size']} karakter")
                    created = time.strftime('%Y-%m-%d %H:%M', time.localtime(metadata['created']))
                    print(f"      📅 Oluşturulma: {created}")
    
    def show_program(self, program_name: str, extension: Optional[str] = None) -> None:
        """Program içeriğini göster"""
        if program_name not in self.programs:
            print(f"[PDS-X] ❌ Program bulunamadı: {program_name}")
            return
        
        prog_data = self.programs[program_name]
        
        if extension:
            if extension not in prog_data:
                print(f"[PDS-X] ❌ Uzantı bulunamadı: {program_name}{extension}")
                return
            extensions_to_show = [extension]
        else:
            extensions_to_show = list(prog_data.keys())
        
        for ext in extensions_to_show:
            data = prog_data[ext]
            print(f"\n[PDS-X] 📄 Program: {program_name}{ext}")
            print("-" * 40)
            lines = data['code'].split('\n')
            for i, line in enumerate(lines, 1):
                print(f"{i:3d}: {line}")
    
    def run_program(self, program_name: str) -> bool:
        """Programı çalıştır"""
        if program_name not in self.programs:
            print(f"[PDS-X] ❌ Program bulunamadı: {program_name}")
            return False
        
        prog_data = self.programs[program_name]
        
        # PDS-X BASIC programları (.basx/.libx/.pdsx)
        if '.basx' in prog_data or '.libx' in prog_data or '.pdsx' in prog_data:
            try:
                # Önce .basx, sonra .libx, sonra .pdsx dene
                for ext in ['.basx', '.libx', '.pdsx']:
                    if ext in prog_data:
                        code = prog_data[ext]['code']
                        print(f"[PDS-X] 🔧 {ext} programı çalıştırılıyor...")
                        
                        if REAL_PDSX_AVAILABLE and self.pdsx_interpreter:
                            # Gerçek PDS-X interpreter kullan
                            try:
                                success = self.pdsx_interpreter.run_program(code)
                                if success:
                                    return True
                            except Exception as e:
                                print(f"[PDS-X] ⚠️ Ana interpreter hatası: {e}")
                                
                        # Fallback: Command executor ile çalıştır
                        if REAL_PDSX_AVAILABLE:
                            try:
                                # Command executor ile satır satır çalıştır
                                lines = [line.strip() for line in code.split('\n') if line.strip()]
                                for line in lines:
                                    if line and not line.startswith('#'):
                                        # Bu satır placeholder - gerçek command executor entegrasyonu gerekli
                                        print(f"[PDS-X] 📝 {line}")
                                print(f"[PDS-X] ✅ {ext} programı tamamlandı")
                                return True
                            except Exception as e:
                                print(f"[PDS-X] ⚠️ Command executor hatası: {e}")
                        
                        print(f"[PDS-X] ❌ {ext} programı çalıştırılamadı")
                        continue
                            
                print(f"[PDS-X] ❌ Program çalıştırılamadı: {program_name}")
                return False
                
            except Exception as e:
                print(f"[PDS-X] ❌ PDS-X BASIC çalıştırma hatası: {e}")
                return False
        
        # Python programı varsa çalıştır
        elif '.py' in prog_data:
            try:
                code = prog_data['.py']['code']
                print("[PDS-X] 🐍 Python programı çalıştırılıyor...")
                exec(code)
                return True
            except Exception as e:
                print(f"[PDS-X] ❌ Python çalıştırma hatası: {e}")
                return False
        
        # JavaScript programı varsa çalıştır (Node.js gerekli)
        elif '.js' in prog_data:
            try:
                code = prog_data['.js']['code']
                print("[PDS-X] 🟨 JavaScript programı çalıştırılıyor...")
                
                # Geçici dosya oluştur
                import tempfile
                with tempfile.NamedTemporaryFile(mode='w', suffix='.js', delete=False) as f:
                    f.write(code)
                    temp_file = f.name
                
                # Node.js ile çalıştır
                result = subprocess.run(['node', temp_file], 
                                      capture_output=True, text=True, timeout=30)
                
                # Geçici dosyayı sil
                os.unlink(temp_file)
                
                if result.returncode == 0:
                    print(result.stdout, end='')
                    return True
                else:
                    print(f"[PDS-X] ❌ JavaScript hatası: {result.stderr}")
                    return False
                    
            except FileNotFoundError:
                print("[PDS-X] ❌ Node.js bulunamadı. JavaScript çalıştırmak için Node.js yükleyin.")
                return False
            except Exception as e:
                print(f"[PDS-X] ❌ JavaScript çalıştırma hatası: {e}")
                return False
        
        # Diğer uzantılar için
        available_exts = list(prog_data.keys())
        print(f"[PDS-X] ℹ️ Program mevcut uzantıları: {', '.join(available_exts)}")
        print(f"[PDS-X] ℹ️ Şu anda sadece .py ve .js programları çalıştırılabilir")
        
        return False

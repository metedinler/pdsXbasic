#!/usr/bin/env python3
"""
Multi-Line Program Manager REPL Test
Çok satırlı program desteğini test eder
"""

import sys
import os
import json
import tempfile
import shutil
import time
import io
from contextlib import redirect_stdout, redirect_stderr

# PDS-X modüllerini import et
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from reply_extension import ReplyExtension, MultiLineProgramManager
from pdsx_repl import REPLSession


def test_program_manager():
    """Program manager temel işlevlerini test et"""
    print("🔹 Program Manager Temel Testleri")
    
    # Geçici dizin oluştur
    with tempfile.TemporaryDirectory() as temp_dir:
        manager = MultiLineProgramManager(temp_dir)
        
        # Test 1: Python programı yazma
        print("  ✓ Python programı yazma...")
        assert manager.start_program("PROGRAM hello.py")
        assert manager.add_line("print('Merhaba PDS-X!')")
        assert manager.add_line("print('Multi-line çalışıyor!')")
        assert manager.end_program()
        
        # Test 2: Program listele
        print("  ✓ Program listeleme...")
        programs = manager._get_all_programs()
        assert "hello" in programs
        assert ".py" in programs["hello"]
        
        # Test 3: Program göster
        print("  ✓ Program gösterme...")
        content = manager._get_program_content("hello", ".py")
        assert "Merhaba PDS-X!" in content
        
        # Test 4: JavaScript programı yazma
        print("  ✓ JavaScript programı yazma...")
        assert manager.start_program("PROGRAM test.js")
        assert manager.add_line("console.log('Hello from JS!');")
        assert manager.add_line("let x = 42;")
        assert manager.add_line("console.log('Answer:', x);")
        assert manager.end_program()
        
        # Test 5: Mevcut program listesi
        print("  ✓ Çok programlı listeleme...")
        programs = manager._get_all_programs()
        assert "hello" in programs
        assert "test" in programs
        
        print("✅ Program Manager testleri başarılı!")


def test_repl_integration():
    """REPL entegrasyonunu test et"""
    print("\n🔹 REPL Entegrasyon Testleri")
    
    # Geçici dizin oluştur
    with tempfile.TemporaryDirectory() as temp_dir:
        # REPLSession oluştur (mock)
        class MockREPLSession:
            def __init__(self):
                self.program_manager = MultiLineProgramManager(temp_dir)
                self.reply_extension = ReplyExtension()
                self.reply_extension.program_manager = self.program_manager
            
            def execute_repl_command(self, cmd):
                """Mock execute_repl_command method"""
                # Program komutları kontrolü
                if self.program_manager:
                    cmd_upper = cmd.upper()
                    
                    if cmd_upper.startswith('PROGRAM '):
                        if self.program_manager.start_program(cmd):
                            return True
                        else:
                            return True
                            
                    elif cmd_upper.startswith('RUN PROGRAM '):
                        import re
                        match = re.match(r'RUN PROGRAM\s+([a-zA-Z_][a-zA-Z0-9_]*)', cmd, re.IGNORECASE)
                        if match:
                            program_name = match.group(1)
                            return self.program_manager.run_program(program_name)
                        return False
                        
                    elif cmd_upper == 'LIST':
                        self.program_manager.list_programs()
                        return True
                
                return False
        
        repl = MockREPLSession()
        
        # Test 1: Program komutları
        print("  ✓ PROGRAM komutu...")
        result = repl.execute_repl_command("PROGRAM calc.py")
        assert result == True
        
        # Satır ekle
        assert repl.program_manager.add_line("def add(a, b):")
        assert repl.program_manager.add_line("    return a + b")
        assert repl.program_manager.add_line("")
        assert repl.program_manager.add_line("print('Hesaplama:', add(5, 3))")
        assert repl.program_manager.end_program()
        
        # Test 2: LIST komutu
        print("  ✓ LIST komutu...")
        result = repl.execute_repl_command("LIST")
        assert result == True
        
        # Test 3: RUN PROGRAM komutu
        print("  ✓ RUN PROGRAM komutu...")
        f = io.StringIO()
        with redirect_stdout(f):
            result = repl.execute_repl_command("RUN PROGRAM calc")
        output = f.getvalue()
        
        # Çıktıyı kontrol et
        assert "Hesaplama: 8" in output or "8" in output
        
        print("✅ REPL entegrasyon testleri başarılı!")


def test_encryption_compression():
    """Şifreleme ve sıkıştırma testleri"""
    print("\n🔹 Şifreleme/Sıkıştırma Testleri")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        manager = MultiLineProgramManager(temp_dir)
        
        # Test veri
        test_content = "print('Bu bir test programıdır')\nfor i in range(10):\n    print(f'Sayı: {i}')"
        
        # Test 1: Sıkıştırma
        print("  ✓ Sıkıştırma testi...")
        compressed = manager._compress_content(test_content)
        decompressed = manager._decompress_content(compressed)
        assert decompressed == test_content
        
        # Test 2: Şifreleme
        print("  ✓ Şifreleme testi...")
        password = "test123"
        encrypted = manager._encrypt_content(test_content, password)
        decrypted = manager._decrypt_content(encrypted, password)
        assert decrypted == test_content
        
        # Test 3: Hem sıkıştırma hem şifreleme
        print("  ✓ Karma test (sıkıştırma + şifreleme)...")
        compressed = manager._compress_content(test_content)
        encrypted = manager._encrypt_content(compressed, password)
        decrypted = manager._decrypt_content(encrypted, password)
        final = manager._decompress_content(decrypted)
        assert final == test_content
        
        print("✅ Şifreleme/sıkıştırma testleri başarılı!")


def main():
    """Ana test fonksiyonu"""
    print("🚀 Multi-Line Program Manager Kapsamlı Test")
    print("=" * 50)
    
    try:
        test_program_manager()
        test_repl_integration()
        test_encryption_compression()
        
        print("\n" + "=" * 50)
        print("🎉 TÜM TESTLER BAŞARILI!")
        print("✅ Multi-line program desteği tamamen hazır")
        print("✅ REPL entegrasyonu çalışıyor")
        print("✅ Şifreleme/sıkıştırma aktif")
        
    except Exception as e:
        print(f"\n❌ Test hatası: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

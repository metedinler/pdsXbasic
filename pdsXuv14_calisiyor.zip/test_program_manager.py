from program_manager import MultiLineProgramManager

# Test programı oluştur
manager = MultiLineProgramManager()

print('=== PDS-X BASIC Test Programı ===')

# BASX programı oluştur
manager.start_program('PROGRAM test.basx')
manager.add_line('10 PRINT "PDS-X BASIC Test"')
manager.add_line('20 LET A = 10')
manager.add_line('30 LET B = 5')
manager.add_line('40 PRINT "A =", A')
manager.add_line('50 PRINT "B =", B')
manager.add_line('60 PRINT "Toplam:", A + B')
manager.add_line('70 FOR I = 1 TO 3')
manager.add_line('80 PRINT "Sayı:", I')
manager.add_line('90 NEXT I')
manager.add_line('100 END')
manager.end_program()

print('\n=== Program Listesi ===')
manager.list_programs()

print('\n=== Program Çalıştırma ===')
manager.run_program('test')

print('\n=== LibX Programı Test ===')

# LibX programı oluştur
manager.start_program('PROGRAM math.libx')
manager.add_line('PRINT "LibX Math Library Test"')
manager.add_line('LET PI = 3.14159')
manager.add_line('LET R = 5')
manager.add_line('LET AREA = PI * R * R')
manager.add_line('PRINT "Yarıçap:", R')
manager.add_line('PRINT "Alan:", AREA')
manager.end_program()

print('\nLibX programı çalıştırılıyor...')
manager.run_program('math')

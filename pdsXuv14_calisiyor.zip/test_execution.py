#!/usr/bin/env python3
"""
PDS-X Program Execution Test
Hangi dosya türlerinin çalıştırılabildiğini test eder
"""

import sys
import os

# PDS-X modüllerini import et
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from program_manager import MultiLineProgramManager


def test_program_execution():
    """Farklı program türlerinin çalıştırılabilirliğini test et"""
    print("🧪 PDS-X Program Execution Test")
    print("=" * 50)
    
    manager = MultiLineProgramManager()
    
    # Test 1: Python programı
    print("\n📝 Test 1: Python Program")
    print("-" * 30)
    
    manager.start_program("PROGRAM test.py")
    manager.add_line("print('✅ Python çalışıyor!')")
    manager.add_line("x = 5 + 3")
    manager.add_line("print(f'Hesaplama: {x}')")
    manager.end_program()
    
    print("🚀 Python programını çalıştırıyoruz:")
    success = manager.run_program("test")
    print(f"Sonuç: {'✅ Başarılı' if success else '❌ Başarısız'}")
    
    # Test 2: JavaScript programı
    print("\n📝 Test 2: JavaScript Program")
    print("-" * 30)
    
    manager.start_program("PROGRAM test.js")
    manager.add_line("console.log('JavaScript test');")
    manager.add_line("let result = 10 * 2;")
    manager.add_line("console.log('Result:', result);")
    manager.end_program()
    
    print("🚀 JavaScript programını çalıştırmaya çalışıyoruz:")
    success = manager.run_program("test")  # Aynı isimde hem .py hem .js var
    print(f"Sonuç: {'✅ Başarılı' if success else '❌ Başarısız'}")
    
    # Test 3: PDS-X BASIC programı
    print("\n📝 Test 3: PDS-X BASIC Program")
    print("-" * 30)
    
    manager.start_program("PROGRAM basic.basx")
    manager.add_line("10 PRINT \"PDS-X BASIC Test\"")
    manager.add_line("20 LET A = 10")
    manager.add_line("30 LET B = 5")
    manager.add_line("40 PRINT \"Toplam:\", A + B")
    manager.end_program()
    
    print("🚀 PDS-X BASIC programını çalıştırmaya çalışıyoruz:")
    success = manager.run_program("basic")
    print(f"Sonuç: {'✅ Başarılı' if success else '❌ Başarısız'}")
    
    # Desteklenen uzantılar tablosu
    print("\n📋 Desteklenen Program Türleri:")
    print("=" * 50)
    print("| Uzantı | Dil          | Çalıştırılabilir | Şifreleme | Sıkıştırma |")
    print("|--------|--------------|------------------|-----------|------------|")
    
    for ext, props in manager.supported_extensions.items():
        executable = "✅" if props['executable'] else "❌"
        encrypt = "✅" if props['encrypt'] else "❌"
        compress = "✅" if props['compress'] else "❌"
        name = props['name']
        print(f"| {ext:<6} | {name:<12} | {executable:<16} | {encrypt:<9} | {compress:<10} |")
    
    print("\n💡 Sonuç:")
    print("   • ✅ Python (.py) dosyaları çalıştırılabilir")
    print("   • ❌ JavaScript (.js) dosyaları henüz çalıştırılamaz")
    print("   • ❌ PDS-X BASIC (.basx) dosyaları henüz çalıştırılamaz")
    print("   • ❌ Diğer türler sadece kayıt ve görüntüleme için")


if __name__ == "__main__":
    test_program_execution()

#!/usr/bin/env python3
"""
Basit Multi-Line Program Manager Test
"""

import sys
import os
import tempfile

# PDS-X modüllerini import et
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from program_manager import MultiLineProgramManager


def test_basic_functionality():
    """Temel işlevleri test et"""
    print("🔹 Temel Fonksiyon Testleri")
    
    # Geçici dizin oluştur
    with tempfile.TemporaryDirectory() as temp_dir:
        manager = MultiLineProgramManager()
        
        # Test 1: Python programı yazma
        print("  ✓ Python programı yazma...")
        assert manager.start_program("PROGRAM hello.py")
        assert manager.add_line("print('Merhaba PDS-X!')")
        assert manager.add_line("print('Multi-line çalışıyor!')")
        assert manager.end_program()
        
        # Test 2: Program listele
        print("  ✓ Program listeleme...")
        programs = manager._get_all_programs()
        assert "hello" in programs
        assert ".py" in programs["hello"]
        
        print("✅ Temel testler başarılı!")


def test_repl_commands():
    """REPL komutlarını test et"""
    print("\n🔹 REPL Komut Testleri")
    
    with tempfile.TemporaryDirectory() as temp_dir:
        manager = MultiLineProgramManager()
        
        # Test 1: Program başlatma
        result = manager.start_program("PROGRAM calc.py")
        assert result == True
        
        # Test 2: Satır ekleme
        assert manager.add_line("def add(a, b):")
        assert manager.add_line("    return a + b")
        assert manager.add_line("print('Test:', add(2, 3))")
        
        # Test 3: Program bitirme
        assert manager.end_program()
        
        print("✅ REPL komut testleri başarılı!")


def main():
    """Ana test fonksiyonu"""
    print("🚀 Basit Multi-Line Program Manager Test")
    print("=" * 40)
    
    try:
        test_basic_functionality()
        test_repl_commands()
        
        print("\n" + "=" * 40)
        print("🎉 TÜM TESTLER BAŞARILI!")
        print("✅ Multi-line program desteği çalışıyor")
        
    except Exception as e:
        print(f"\n❌ Test hatası: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

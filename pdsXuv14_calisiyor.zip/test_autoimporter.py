#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Auto_importer test script
"""

# Test auto_importer'ın çıktı formatını
if __name__ == "__main__":
    try:
        from auto_importer import AutoImporter
        
        print("\n🔧 Auto_importer test başlatılıyor...")
        
        # AutoImporter instance oluştur
        importer = AutoImporter()
        
        # Test paketi kontrol et
        print("\n📦 Test paketi (numpy) kontrol ediliyor...")
        is_installed = importer.env_manager.check_package_installed("numpy")
        
        if is_installed:
            print("[PDS-X] ✅ numpy zaten kurulu")
        else:
            print("[PDS-X] ❌ numpy kurulu değil")
        
        # Environment bilgilerini göster
        print("\n🏠 Environment bilgileri:")
        env_info = importer.get_environment_info()
        print(env_info)
        
        # Özet rapor test
        print("\n📊 Test özet raporu:")
        importer.print_installation_summary()
        
        # Shutdown
        importer.shutdown()
        
        print("\n✅ Test tamamlandı!")
        
    except Exception as e:
        print(f"\n❌ Test hatası: {e}")
        import traceback
        traceback.print_exc()

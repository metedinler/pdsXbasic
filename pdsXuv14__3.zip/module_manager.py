"""
module_manager.py - PDS-X BASIC v14u Modül Yönetim Sistemi
Version: 1.0.0
Date: May 14, 2025
Author: xAI (Grok 3 ile oluşturuldu)
"""

import os
import sys
import importlib
import logging
import json
import threading
from pathlib import Path
from typing import Dict, List, Optional, Set
import shutil

from pdsx_exception import PdsXException
from save_load_system2 import SaveLoadSystem as SaveLoadSystem2
from core import synchronized
from autoinstaller import DependencyManager

log = logging.getLogger(__name__)

class ModuleManager:
    def __init__(self, base_path: str, secure_mode: bool = True):
        self.base_path = Path(base_path)
        self.secure_mode = secure_mode
        self.loaded_modules: Dict[str, object] = {}
        self.module_cache: Dict[str, object] = {}
        self.imported_files: Set[str] = set()
        self.aliases: Dict[str, str] = {}
        self.lock = threading.Lock()
        self.save_load = SaveLoadSystem2()
        
        # Bağımlılık yöneticisini başlat
        self.dependency_manager = DependencyManager(base_path)
        
        # Modül dizinini oluştur
        self.module_dir = self.base_path / "modules"
        self.module_dir.mkdir(parents=True, exist_ok=True)

    @synchronized
    def load_module(self, module_name: str, alias: Optional[str] = None) -> object:
        """
        Belirtilen modülü yükler.
        Args:
            module_name: Yüklenecek modülün adı veya yolu
            alias: Modül için isteğe bağlı takma ad
        Returns:
            Yüklenen modül nesnesi
        """
        try:
            # Modülü ara
            module_path = self._find_module(module_name)
            if not module_path:
                raise PdsXException(f"Modül bulunamadı: {module_name}")

            # Yolu doğrula
            abs_path = os.path.abspath(module_path)
            if self.secure_mode and not self._is_allowed_path(abs_path):
                raise PdsXException(f"Güvenli modda dış modül yüklenemez: {module_name}")

            # Modülü yükle
            if abs_path in self.module_cache:
                module = self.module_cache[abs_path]
            else:
                module_name = os.path.splitext(os.path.basename(module_path))[0]
                if alias:
                    module_name = alias
                    self.aliases[alias] = abs_path

                spec = importlib.util.spec_from_file_location(module_name, abs_path)
                if not spec:
                    raise PdsXException(f"Modül spec oluşturulamadı: {module_name}")

                module = importlib.util.module_from_spec(spec)
                sys.modules[module_name] = module
                spec.loader.exec_module(module)
                self.module_cache[abs_path] = module

            # Modülün bağımlılıklarını kontrol et ve yükle
            if hasattr(module, "__pdsX_exports__"):
                dependencies = module.__pdsX_exports__.get("variables", {}).get("dependencies", [])
                if dependencies:
                    if not self.dependency_manager.install_packages(module_name, dependencies):
                        raise PdsXException(f"Modül bağımlılıkları yüklenemedi: {module_name}")
            
            # Modül ortam değişkenlerini ayarla
            env = self.dependency_manager.get_module_environment(module_name)
            if env:
                os.environ.update(env)

            self.loaded_modules[module_name] = module
            self.imported_files.add(abs_path)
            log.info(f"Modül yüklendi: {module_name} ({abs_path})")

            return module

        except Exception as e:
            log.error(f"Modül yükleme hatası: {str(e)}")
            raise PdsXException(f"Modül yükleme hatası: {str(e)}")

    @synchronized  
    def unload_module(self, module_name: str) -> None:
        """
        Belirtilen modülü kaldırır.
        """
        try:
            if module_name in self.loaded_modules:
                # Modülün paketlerini temizle
                self.dependency_manager.uninstall_module_packages(module_name)
                module = self.loaded_modules[module_name]
                abs_path = next(path for path, mod in self.module_cache.items() if mod == module)
                
                # Modülü sys.modules'dan kaldır
                if module_name in sys.modules:
                    del sys.modules[module_name]
                
                # Cache'den kaldır    
                del self.module_cache[abs_path]
                del self.loaded_modules[module_name]
                self.imported_files.remove(abs_path)
                
                # Takma adı varsa kaldır
                if module_name in self.aliases:
                    del self.aliases[module_name]
                    
                log.info(f"Modül kaldırıldı: {module_name}")
            else:
                raise PdsXException(f"Modül bulunamadı: {module_name}")
                
        except Exception as e:
            log.error(f"Modül kaldırma hatası: {str(e)}")
            raise PdsXException(f"Modül kaldırma hatası: {str(e)}")

    @synchronized
    def list_modules(self) -> List[Dict[str, str]]:
        """
        Yüklü modüllerin listesini döndürür.
        """
        modules = []
        try:
            for name, module in self.loaded_modules.items():
                abs_path = next(path for path, mod in self.module_cache.items() if mod == module)
                modules.append({
                    "name": name,
                    "path": abs_path,
                    "alias": next((alias for alias, path in self.aliases.items() if path == abs_path), None)
                })
            return modules
        except Exception as e:
            log.error(f"Modül listeleme hatası: {str(e)}")
            raise PdsXException(f"Modül listeleme hatası: {str(e)}")

    @synchronized
    def save_module(self, module_name: str, file_path: Optional[str] = None) -> str:
        """
        Belirtilen modülü .basx formatında kaydeder.
        Args:
            module_name: Kaydedilecek modülün adı
            file_path: İsteğe bağlı kayıt yolu. Belirtilmezse varsayılan dizine kaydedilir.
        Returns:
            Kaydedilen dosyanın yolu
        """
        try:
            if module_name not in self.loaded_modules:
                raise PdsXException(f"Modül bulunamadı: {module_name}")

            module = self.loaded_modules[module_name]
            source_path = next(path for path, mod in self.module_cache.items() if mod == module)

            if not file_path:
                file_path = self.module_dir / f"{module_name}.basx"
            
            # Modül içeriğini oku
            with open(source_path, "r", encoding="utf-8") as f:
                content = f.read()

            # Metadata hazırla    
            metadata = {
                "name": module_name,
                "created": str(Path(source_path).stat().st_mtime),
                "source_path": str(source_path),
                "dependencies": self._get_module_dependencies(module)
            }

            # .basx formatında kaydet
            self.save_load.save_file(
                file_path,
                {
                    "metadata": metadata,
                    "content": content
                },
                format="basx"
            )

            log.info(f"Modül kaydedildi: {module_name} -> {file_path}")
            return str(file_path)

        except Exception as e:
            log.error(f"Modül kaydetme hatası: {str(e)}")
            raise PdsXException(f"Modül kaydetme hatası: {str(e)}")

    def _find_module(self, module_name: str) -> Optional[str]:
        """
        Modül dosyasının yolunu bulur.
        """
        # Tam yol verilmişse doğrudan kullan
        if os.path.exists(module_name):
            return module_name

        # .basx uzantısı varsa modules dizininde ara
        if module_name.endswith('.basx'):
            path = self.module_dir / module_name
            if path.exists():
                return str(path)

        # Python modülü olarak ara
        path = self.module_dir / f"{module_name}.py"
        if path.exists():
            return str(path)

        return None

    def _is_allowed_path(self, path: str) -> bool:
        """
        Güvenli modda yolun izinli olup olmadığını kontrol eder.
        """
        if not self.secure_mode:
            return True
            
        path = os.path.abspath(path)
        base = os.path.abspath(self.base_path)
        return path.startswith(base)

    def _get_module_dependencies(self, module: object) -> List[str]:
        """
        Modülün bağımlılıklarını bulur.
        """
        dependencies = []
        if hasattr(module, "__depends__"):
            dependencies.extend(getattr(module, "__depends__"))
        return dependencies

    def edit_module(self, module_name: str) -> str:
        """
        Modülü düzenleme için hazırlar. Modülün kaynak dosyasının yolunu döndürür.
        """
        try:
            if module_name not in self.loaded_modules:
                raise PdsXException(f"Modül bulunamadı: {module_name}")

            module = self.loaded_modules[module_name]
            source_path = next(path for path, mod in self.module_cache.items() if mod == module)

            # Dosyanın varlığını kontrol et
            if not os.path.exists(source_path):
                raise PdsXException(f"Modül kaynak dosyası bulunamadı: {source_path}")

            return source_path

        except Exception as e:
            log.error(f"Modül düzenleme hatası: {str(e)}")
            raise PdsXException(f"Modül düzenleme hatası: {str(e)}")

@echo off
setx PATH "%PATH%;;.pdsx_isolated_env\Scripts"
echo PATH g�ncellendi.
pause
